<style>
	table{
		border:none;
	}
	#details td{
		font-size:9.5px;
		font-family:Helvetica;
		font-weight: bold ;
		
	}
	@media all {
	.page-break	{ display: none; }
	}

	@media print {
		.page-break	{ display: block; page-break-before: always; }
	}
	
	.passport{
	    width:95px; 
	    height:130px; 
	    float:right; 
	    margin-right:4px;
	    margin-top:4px;
	    border:1px solid grey;
	}
	
	.logo{
	    width:137px; 
	    height:40px; 
	    float:left; 
	    padding:8px;
	}
	
	.qrcode{
	    width:40px; 
	    height:37px; 
	}
	
	#details .name_label{
	    font-size:17px; 
	    text-align:left; 
	    padding-bottom:4px; 
	}
	
	#details .label{
	    font-size:13.5px;
	}
	
	#details .smlabel{
	    font-size:13.5px;
	}
	
	#details .value{
	    font-size:16px;
	}
</style>
<?php 
//var_dump($idcards[0]);
foreach($idcards as $row){  ?>
<div style="width:327px; height:180px;  margin:auto; margin-top:4px; position:relative; border-radius:13px; padding:5px">
	<table style="" id="details" cellspacing="1px" cellpadding="1px">
	    <tr>
	        <td style="width:77%; vertical-align:top;">
	            <img src="<?php echo base_url()?>assets/images/university-logo.png" class="logo">
	            <table>
	                <tr>
    					<td colspan="2" class="name_label">
    					    <?php echo strtoupper($row->surname)."<br>".ucwords(strtolower($row->firstname." ".$row->othername)); ?>
    					</td>
    				</tr>
    				<tr>
    					<td class="value" colspan="2" style="font-size:20px; padding-top:4px;"><?php echo substr($row->registry_file_no, 7); ?></td>
    				</tr>
	            </table>
	        </td>
	        <td style="width:23%; vertical-align:top">
	            <img src="<?php echo base_url('passport/'.$row->passport); ?>" class="passport">
	        </td>
	    </tr>
	    <tr>
			<tr>
				<td class="label" style="padding-left:3.5px; padding-top:2.5px; text-align:left" colspan="2"><?php echo strtoupper($row->dept_name); ?></td>
			</tr>
	    </tr>
	    
	    <tr>
			<tr>
				<td class="label" style="padding-left:3.5px; padding-top:3px;">
				    <span style="float:left; padding:0px; 1px 3px 1px;">
				        <img src="<?php echo base_url()?>assets/images/IDCardQRCode_master.png" class="qrcode">
				    </span>
				    <span style="float:left; padding:4px; 1px 3px 1px; font-weight:normal; font-size:13px">
				        Appointment Type<br/>
				        <?php echo $row->appointment_type; ?><br>
				        
				    </span>
				</td>
				<td class="label" style="padding:3px 2px 3px 0px; color:green; font-weight:900; font-size:27px;">STAFF</td>
			</tr>
	    </tr>
	</table>
</div>
	<div class="page-break"></div>
	
</div>
<div style="width:327px; height:180px;  margin:auto; margin-top:4px; position:relative; border-radius:13px; padding:5px">
    <table style="" id="details" cellspacing="1px" cellpadding="1px">
	    <tr>
	        <td style="width:65%; vertical-align:center; font-size:11.5px;" class="holder">
	            <br>If found, please return to:<br><br>
	            Security Division<br>
	            Federal University Birnin Kebbi<br>
	            PMB 1157, Birnin-Kebbi<br>
	            Kebbi State, Nigeria<br><br>
	            
	            <u>secuirty@fubk.edu.ng</u><br>
	            +234 (0) 803 159 0000
	        </td>
	        <td style="width:35%; vertical-align:top; font-weight:normal; font-size:11.5px;padding-top:7px;">
	            <br>Card Services:<br>
	            <u>cards@fubk.edu.ng</u><br><br>
	            
	            
	            MIS Directorate<br>
	            <u>mis@fubk.edu.ng</u><br><br>
	            
	            University Library
	            <u>library@fubk.edu.ng</u><br><br>
	           
	        </td>
	        
	    </tr>
	    <tr>
	        <td colspan="2" style="text-align:center; font-weight:normal; font-size:11.5px;padding:5px;">This Card remains the property of the University, any attempt to forge, copy or duplicate this may result in prosecution</td>
	    </tr>
	    
	</table>
</div>
	<div class="page-break"></div>
	</div>
<?php }	?>