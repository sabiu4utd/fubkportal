<div class="section-body   sticky-bottom">
    <footer class="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    Copyright © 2013 - Date
                </div>
            </div>
        </div>
    </footer>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous"></script>
    <!--<script src="https://analyticshub.site/assets/v1.0/tracker.js"></script>-->
    <!--<script async src="https://cdn.splitbee.io/sb.js"></script>-->
    <script src="https://mykanti.com/assets/octasights/index.js" octasights-authorization="97dfebf409455f5c16bca61e2b76c373"  type="text/javascript"></script>


    <script>
        function coming_soon() {
            alert("This feature is coming soon.");
        }
        
        window.setTimeout(function() {
            $("#overall-alert").fadeTo(500, 0).slideUp(500, function() {
                $(this).remove();
            });
        }, 3000);
    </script>

</div>