<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-02-28 15:18:58 --> Config Class Initialized
INFO - 2025-02-28 15:18:58 --> Hooks Class Initialized
DEBUG - 2025-02-28 15:18:58 --> UTF-8 Support Enabled
INFO - 2025-02-28 15:18:58 --> Utf8 Class Initialized
INFO - 2025-02-28 15:18:58 --> URI Class Initialized
DEBUG - 2025-02-28 15:18:58 --> No URI present. Default controller set.
INFO - 2025-02-28 15:18:58 --> Router Class Initialized
INFO - 2025-02-28 15:18:58 --> Output Class Initialized
INFO - 2025-02-28 15:18:58 --> Security Class Initialized
DEBUG - 2025-02-28 15:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 15:18:58 --> Input Class Initialized
INFO - 2025-02-28 15:18:58 --> Language Class Initialized
INFO - 2025-02-28 15:18:58 --> Loader Class Initialized
INFO - 2025-02-28 15:18:58 --> Helper loaded: url_helper
INFO - 2025-02-28 15:18:58 --> Helper loaded: file_helper
INFO - 2025-02-28 15:18:58 --> Helper loaded: jwt_helper
INFO - 2025-02-28 15:18:58 --> Database Driver Class Initialized
ERROR - 2025-02-28 15:18:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'fubkvsdd_mis'@'localhost' (using password: YES) C:\wamp64\www\fubkportal\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-02-28 15:18:58 --> Unable to connect to the database
INFO - 2025-02-28 15:18:58 --> Language file loaded: language/english/db_lang.php
INFO - 2025-02-28 15:22:45 --> Config Class Initialized
INFO - 2025-02-28 15:22:45 --> Hooks Class Initialized
DEBUG - 2025-02-28 15:22:45 --> UTF-8 Support Enabled
INFO - 2025-02-28 15:22:45 --> Utf8 Class Initialized
INFO - 2025-02-28 15:22:45 --> URI Class Initialized
DEBUG - 2025-02-28 15:22:45 --> No URI present. Default controller set.
INFO - 2025-02-28 15:22:45 --> Router Class Initialized
INFO - 2025-02-28 15:22:45 --> Output Class Initialized
INFO - 2025-02-28 15:22:45 --> Security Class Initialized
DEBUG - 2025-02-28 15:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 15:22:45 --> Input Class Initialized
INFO - 2025-02-28 15:22:45 --> Language Class Initialized
INFO - 2025-02-28 15:22:45 --> Loader Class Initialized
INFO - 2025-02-28 15:22:45 --> Helper loaded: url_helper
INFO - 2025-02-28 15:22:45 --> Helper loaded: file_helper
INFO - 2025-02-28 15:22:45 --> Helper loaded: jwt_helper
INFO - 2025-02-28 15:22:45 --> Database Driver Class Initialized
INFO - 2025-02-28 15:22:45 --> Email Class Initialized
INFO - 2025-02-28 15:22:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 15:22:45 --> PHPMailer loaded successfully
INFO - 2025-02-28 15:22:45 --> Upload Class Initialized
INFO - 2025-02-28 15:22:45 --> Model "Auth_model" initialized
INFO - 2025-02-28 15:22:45 --> Controller Class Initialized
INFO - 2025-02-28 15:22:45 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 15:22:45 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 16:02:44 --> Config Class Initialized
INFO - 2025-02-28 16:02:44 --> Hooks Class Initialized
DEBUG - 2025-02-28 16:02:44 --> UTF-8 Support Enabled
INFO - 2025-02-28 16:02:44 --> Utf8 Class Initialized
INFO - 2025-02-28 16:02:44 --> URI Class Initialized
DEBUG - 2025-02-28 16:02:44 --> No URI present. Default controller set.
INFO - 2025-02-28 16:02:44 --> Router Class Initialized
INFO - 2025-02-28 16:02:44 --> Output Class Initialized
INFO - 2025-02-28 16:02:44 --> Security Class Initialized
DEBUG - 2025-02-28 16:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 16:02:44 --> Input Class Initialized
INFO - 2025-02-28 16:02:44 --> Language Class Initialized
INFO - 2025-02-28 16:02:44 --> Loader Class Initialized
INFO - 2025-02-28 16:02:44 --> Helper loaded: url_helper
INFO - 2025-02-28 16:02:44 --> Helper loaded: file_helper
INFO - 2025-02-28 16:02:44 --> Helper loaded: jwt_helper
INFO - 2025-02-28 16:02:44 --> Database Driver Class Initialized
INFO - 2025-02-28 16:02:44 --> Email Class Initialized
INFO - 2025-02-28 16:02:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 16:02:44 --> PHPMailer loaded successfully
INFO - 2025-02-28 16:02:44 --> Upload Class Initialized
INFO - 2025-02-28 16:02:44 --> Model "Auth_model" initialized
INFO - 2025-02-28 16:02:44 --> Controller Class Initialized
INFO - 2025-02-28 16:02:44 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 16:02:44 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 16:08:53 --> Config Class Initialized
INFO - 2025-02-28 16:08:53 --> Hooks Class Initialized
DEBUG - 2025-02-28 16:08:53 --> UTF-8 Support Enabled
INFO - 2025-02-28 16:08:53 --> Utf8 Class Initialized
INFO - 2025-02-28 16:08:53 --> URI Class Initialized
DEBUG - 2025-02-28 16:08:53 --> No URI present. Default controller set.
INFO - 2025-02-28 16:08:53 --> Router Class Initialized
INFO - 2025-02-28 16:08:53 --> Output Class Initialized
INFO - 2025-02-28 16:08:53 --> Security Class Initialized
DEBUG - 2025-02-28 16:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 16:08:53 --> Input Class Initialized
INFO - 2025-02-28 16:08:53 --> Language Class Initialized
INFO - 2025-02-28 16:08:53 --> Loader Class Initialized
INFO - 2025-02-28 16:08:53 --> Helper loaded: url_helper
INFO - 2025-02-28 16:08:53 --> Helper loaded: file_helper
INFO - 2025-02-28 16:08:53 --> Helper loaded: jwt_helper
INFO - 2025-02-28 16:08:53 --> Database Driver Class Initialized
INFO - 2025-02-28 16:08:53 --> Email Class Initialized
INFO - 2025-02-28 16:08:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 16:08:53 --> PHPMailer loaded successfully
INFO - 2025-02-28 16:08:53 --> Upload Class Initialized
INFO - 2025-02-28 16:08:53 --> Model "Auth_model" initialized
INFO - 2025-02-28 16:08:53 --> Controller Class Initialized
INFO - 2025-02-28 16:08:53 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 16:08:53 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 17:08:58 --> Config Class Initialized
INFO - 2025-02-28 17:08:58 --> Hooks Class Initialized
DEBUG - 2025-02-28 17:08:58 --> UTF-8 Support Enabled
INFO - 2025-02-28 17:08:58 --> Utf8 Class Initialized
INFO - 2025-02-28 17:08:58 --> URI Class Initialized
DEBUG - 2025-02-28 17:08:58 --> No URI present. Default controller set.
INFO - 2025-02-28 17:08:58 --> Router Class Initialized
INFO - 2025-02-28 17:08:58 --> Output Class Initialized
INFO - 2025-02-28 17:08:58 --> Security Class Initialized
DEBUG - 2025-02-28 17:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 17:08:58 --> Input Class Initialized
INFO - 2025-02-28 17:08:58 --> Language Class Initialized
INFO - 2025-02-28 17:08:58 --> Loader Class Initialized
INFO - 2025-02-28 17:08:58 --> Helper loaded: url_helper
INFO - 2025-02-28 17:08:58 --> Helper loaded: file_helper
INFO - 2025-02-28 17:08:58 --> Helper loaded: jwt_helper
INFO - 2025-02-28 17:08:58 --> Database Driver Class Initialized
INFO - 2025-02-28 17:08:58 --> Email Class Initialized
INFO - 2025-02-28 17:08:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 17:08:58 --> PHPMailer loaded successfully
INFO - 2025-02-28 17:08:58 --> Upload Class Initialized
INFO - 2025-02-28 17:08:58 --> Model "Auth_model" initialized
INFO - 2025-02-28 17:08:58 --> Controller Class Initialized
INFO - 2025-02-28 17:08:58 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 17:08:58 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 18:17:54 --> Config Class Initialized
INFO - 2025-02-28 18:17:54 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:17:54 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:17:54 --> Utf8 Class Initialized
INFO - 2025-02-28 18:17:54 --> URI Class Initialized
DEBUG - 2025-02-28 18:17:54 --> No URI present. Default controller set.
INFO - 2025-02-28 18:17:54 --> Router Class Initialized
INFO - 2025-02-28 18:17:54 --> Output Class Initialized
INFO - 2025-02-28 18:17:54 --> Security Class Initialized
DEBUG - 2025-02-28 18:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:17:54 --> Input Class Initialized
INFO - 2025-02-28 18:17:54 --> Language Class Initialized
INFO - 2025-02-28 18:17:54 --> Loader Class Initialized
INFO - 2025-02-28 18:17:54 --> Helper loaded: url_helper
INFO - 2025-02-28 18:17:54 --> Helper loaded: file_helper
INFO - 2025-02-28 18:17:54 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:17:54 --> Database Driver Class Initialized
INFO - 2025-02-28 18:17:54 --> Email Class Initialized
INFO - 2025-02-28 18:17:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:17:54 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:17:54 --> Upload Class Initialized
INFO - 2025-02-28 18:17:54 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:17:54 --> Controller Class Initialized
INFO - 2025-02-28 18:17:54 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 18:17:54 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 18:24:33 --> Config Class Initialized
INFO - 2025-02-28 18:24:33 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:24:33 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:24:33 --> Utf8 Class Initialized
INFO - 2025-02-28 18:24:33 --> URI Class Initialized
DEBUG - 2025-02-28 18:24:33 --> No URI present. Default controller set.
INFO - 2025-02-28 18:24:33 --> Router Class Initialized
INFO - 2025-02-28 18:24:33 --> Output Class Initialized
INFO - 2025-02-28 18:24:33 --> Security Class Initialized
DEBUG - 2025-02-28 18:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:24:33 --> Input Class Initialized
INFO - 2025-02-28 18:24:33 --> Language Class Initialized
INFO - 2025-02-28 18:24:33 --> Loader Class Initialized
INFO - 2025-02-28 18:24:33 --> Helper loaded: url_helper
INFO - 2025-02-28 18:24:33 --> Helper loaded: file_helper
INFO - 2025-02-28 18:24:33 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:24:33 --> Database Driver Class Initialized
INFO - 2025-02-28 18:24:33 --> Email Class Initialized
INFO - 2025-02-28 18:24:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:24:33 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:24:33 --> Upload Class Initialized
INFO - 2025-02-28 18:24:33 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:24:33 --> Controller Class Initialized
INFO - 2025-02-28 18:24:33 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 18:24:33 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 18:24:37 --> Config Class Initialized
INFO - 2025-02-28 18:24:37 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:24:37 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:24:37 --> Utf8 Class Initialized
INFO - 2025-02-28 18:24:37 --> URI Class Initialized
DEBUG - 2025-02-28 18:24:37 --> No URI present. Default controller set.
INFO - 2025-02-28 18:24:37 --> Router Class Initialized
INFO - 2025-02-28 18:24:37 --> Output Class Initialized
INFO - 2025-02-28 18:24:37 --> Security Class Initialized
DEBUG - 2025-02-28 18:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:24:37 --> Input Class Initialized
INFO - 2025-02-28 18:24:37 --> Language Class Initialized
INFO - 2025-02-28 18:24:37 --> Loader Class Initialized
INFO - 2025-02-28 18:24:37 --> Helper loaded: url_helper
INFO - 2025-02-28 18:24:37 --> Helper loaded: file_helper
INFO - 2025-02-28 18:24:37 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:24:37 --> Database Driver Class Initialized
INFO - 2025-02-28 18:24:37 --> Email Class Initialized
INFO - 2025-02-28 18:24:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:24:37 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:24:37 --> Upload Class Initialized
INFO - 2025-02-28 18:24:37 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:24:37 --> Controller Class Initialized
INFO - 2025-02-28 18:24:37 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 18:24:37 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 18:24:38 --> Config Class Initialized
INFO - 2025-02-28 18:24:38 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:24:38 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:24:38 --> Utf8 Class Initialized
INFO - 2025-02-28 18:24:38 --> URI Class Initialized
DEBUG - 2025-02-28 18:24:38 --> No URI present. Default controller set.
INFO - 2025-02-28 18:24:38 --> Router Class Initialized
INFO - 2025-02-28 18:24:38 --> Output Class Initialized
INFO - 2025-02-28 18:24:38 --> Security Class Initialized
DEBUG - 2025-02-28 18:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:24:38 --> Input Class Initialized
INFO - 2025-02-28 18:24:38 --> Language Class Initialized
INFO - 2025-02-28 18:24:38 --> Loader Class Initialized
INFO - 2025-02-28 18:24:38 --> Helper loaded: url_helper
INFO - 2025-02-28 18:24:38 --> Helper loaded: file_helper
INFO - 2025-02-28 18:24:38 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:24:38 --> Database Driver Class Initialized
INFO - 2025-02-28 18:24:38 --> Email Class Initialized
INFO - 2025-02-28 18:24:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:24:38 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:24:38 --> Upload Class Initialized
INFO - 2025-02-28 18:24:38 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:24:38 --> Controller Class Initialized
INFO - 2025-02-28 18:24:38 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 18:24:38 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 18:25:17 --> Config Class Initialized
INFO - 2025-02-28 18:25:17 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:25:17 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:25:17 --> Utf8 Class Initialized
INFO - 2025-02-28 18:25:17 --> URI Class Initialized
DEBUG - 2025-02-28 18:25:17 --> No URI present. Default controller set.
INFO - 2025-02-28 18:25:17 --> Router Class Initialized
INFO - 2025-02-28 18:25:17 --> Output Class Initialized
INFO - 2025-02-28 18:25:17 --> Security Class Initialized
DEBUG - 2025-02-28 18:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:25:17 --> Input Class Initialized
INFO - 2025-02-28 18:25:17 --> Language Class Initialized
INFO - 2025-02-28 18:25:17 --> Loader Class Initialized
INFO - 2025-02-28 18:25:17 --> Helper loaded: url_helper
INFO - 2025-02-28 18:25:17 --> Helper loaded: file_helper
INFO - 2025-02-28 18:25:17 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:25:17 --> Database Driver Class Initialized
INFO - 2025-02-28 18:25:17 --> Email Class Initialized
INFO - 2025-02-28 18:25:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:25:17 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:25:17 --> Upload Class Initialized
INFO - 2025-02-28 18:25:17 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:25:17 --> Controller Class Initialized
INFO - 2025-02-28 18:25:17 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 18:25:17 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 18:27:12 --> Config Class Initialized
INFO - 2025-02-28 18:27:12 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:27:12 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:27:12 --> Utf8 Class Initialized
INFO - 2025-02-28 18:27:12 --> URI Class Initialized
DEBUG - 2025-02-28 18:27:12 --> No URI present. Default controller set.
INFO - 2025-02-28 18:27:12 --> Router Class Initialized
INFO - 2025-02-28 18:27:12 --> Output Class Initialized
INFO - 2025-02-28 18:27:12 --> Security Class Initialized
DEBUG - 2025-02-28 18:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:27:12 --> Input Class Initialized
INFO - 2025-02-28 18:27:12 --> Language Class Initialized
INFO - 2025-02-28 18:27:12 --> Loader Class Initialized
INFO - 2025-02-28 18:27:12 --> Helper loaded: url_helper
INFO - 2025-02-28 18:27:12 --> Helper loaded: file_helper
INFO - 2025-02-28 18:27:12 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:27:12 --> Database Driver Class Initialized
INFO - 2025-02-28 18:27:12 --> Email Class Initialized
INFO - 2025-02-28 18:27:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:27:12 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:27:12 --> Upload Class Initialized
INFO - 2025-02-28 18:27:12 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:27:12 --> Controller Class Initialized
INFO - 2025-02-28 18:27:12 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 18:27:12 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 18:27:14 --> Config Class Initialized
INFO - 2025-02-28 18:27:14 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:27:14 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:27:14 --> Utf8 Class Initialized
INFO - 2025-02-28 18:27:14 --> URI Class Initialized
DEBUG - 2025-02-28 18:27:14 --> No URI present. Default controller set.
INFO - 2025-02-28 18:27:14 --> Router Class Initialized
INFO - 2025-02-28 18:27:14 --> Output Class Initialized
INFO - 2025-02-28 18:27:14 --> Security Class Initialized
DEBUG - 2025-02-28 18:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:27:14 --> Input Class Initialized
INFO - 2025-02-28 18:27:14 --> Language Class Initialized
INFO - 2025-02-28 18:27:14 --> Loader Class Initialized
INFO - 2025-02-28 18:27:14 --> Helper loaded: url_helper
INFO - 2025-02-28 18:27:14 --> Helper loaded: file_helper
INFO - 2025-02-28 18:27:14 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:27:14 --> Database Driver Class Initialized
INFO - 2025-02-28 18:27:14 --> Email Class Initialized
INFO - 2025-02-28 18:27:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:27:14 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:27:14 --> Upload Class Initialized
INFO - 2025-02-28 18:27:14 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:27:14 --> Controller Class Initialized
INFO - 2025-02-28 18:27:14 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 18:27:14 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 18:36:51 --> Config Class Initialized
INFO - 2025-02-28 18:36:51 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:36:51 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:36:51 --> Utf8 Class Initialized
INFO - 2025-02-28 18:36:51 --> URI Class Initialized
DEBUG - 2025-02-28 18:36:51 --> No URI present. Default controller set.
INFO - 2025-02-28 18:36:51 --> Router Class Initialized
INFO - 2025-02-28 18:36:51 --> Output Class Initialized
INFO - 2025-02-28 18:36:51 --> Security Class Initialized
DEBUG - 2025-02-28 18:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:36:51 --> Input Class Initialized
INFO - 2025-02-28 18:36:51 --> Language Class Initialized
INFO - 2025-02-28 18:36:51 --> Loader Class Initialized
INFO - 2025-02-28 18:36:51 --> Helper loaded: url_helper
INFO - 2025-02-28 18:36:51 --> Helper loaded: file_helper
INFO - 2025-02-28 18:36:51 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:36:51 --> Database Driver Class Initialized
INFO - 2025-02-28 18:36:51 --> Email Class Initialized
INFO - 2025-02-28 18:36:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:36:51 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:36:51 --> Upload Class Initialized
INFO - 2025-02-28 18:36:51 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:36:51 --> Controller Class Initialized
INFO - 2025-02-28 18:36:51 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 18:36:51 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 18:36:51 --> File loaded: C:\wamp64\www\fubkportal\application\views\login.php
INFO - 2025-02-28 18:36:51 --> Final output sent to browser
DEBUG - 2025-02-28 18:36:51 --> Total execution time: 0.0319
INFO - 2025-02-28 18:37:51 --> Config Class Initialized
INFO - 2025-02-28 18:37:51 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:37:51 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:37:51 --> Utf8 Class Initialized
INFO - 2025-02-28 18:37:51 --> URI Class Initialized
DEBUG - 2025-02-28 18:37:51 --> No URI present. Default controller set.
INFO - 2025-02-28 18:37:51 --> Router Class Initialized
INFO - 2025-02-28 18:37:51 --> Output Class Initialized
INFO - 2025-02-28 18:37:51 --> Security Class Initialized
DEBUG - 2025-02-28 18:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:37:51 --> Input Class Initialized
INFO - 2025-02-28 18:37:51 --> Language Class Initialized
INFO - 2025-02-28 18:37:51 --> Loader Class Initialized
INFO - 2025-02-28 18:37:51 --> Helper loaded: url_helper
INFO - 2025-02-28 18:37:51 --> Helper loaded: file_helper
INFO - 2025-02-28 18:37:51 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:37:51 --> Database Driver Class Initialized
INFO - 2025-02-28 18:37:51 --> Email Class Initialized
INFO - 2025-02-28 18:37:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:37:51 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:37:51 --> Upload Class Initialized
INFO - 2025-02-28 18:37:51 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:37:51 --> Controller Class Initialized
INFO - 2025-02-28 18:37:51 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 18:37:51 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 18:37:51 --> File loaded: C:\wamp64\www\fubkportal\application\views\login.php
INFO - 2025-02-28 18:37:51 --> Final output sent to browser
DEBUG - 2025-02-28 18:37:51 --> Total execution time: 0.0349
INFO - 2025-02-28 18:38:05 --> Config Class Initialized
INFO - 2025-02-28 18:38:05 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:38:05 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:38:05 --> Utf8 Class Initialized
INFO - 2025-02-28 18:38:05 --> URI Class Initialized
INFO - 2025-02-28 18:38:05 --> Router Class Initialized
INFO - 2025-02-28 18:38:05 --> Output Class Initialized
INFO - 2025-02-28 18:38:05 --> Security Class Initialized
DEBUG - 2025-02-28 18:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:38:05 --> Input Class Initialized
INFO - 2025-02-28 18:38:05 --> Language Class Initialized
INFO - 2025-02-28 18:38:05 --> Loader Class Initialized
INFO - 2025-02-28 18:38:05 --> Helper loaded: url_helper
INFO - 2025-02-28 18:38:05 --> Helper loaded: file_helper
INFO - 2025-02-28 18:38:05 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:38:05 --> Database Driver Class Initialized
INFO - 2025-02-28 18:38:05 --> Email Class Initialized
INFO - 2025-02-28 18:38:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:38:05 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:38:05 --> Upload Class Initialized
INFO - 2025-02-28 18:38:05 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:38:05 --> Controller Class Initialized
INFO - 2025-02-28 18:38:05 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 18:38:05 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 18:38:05 --> File loaded: C:\wamp64\www\fubkportal\application\views\reset.php
INFO - 2025-02-28 18:38:05 --> Final output sent to browser
DEBUG - 2025-02-28 18:38:05 --> Total execution time: 0.0259
INFO - 2025-02-28 18:39:28 --> Config Class Initialized
INFO - 2025-02-28 18:39:28 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:39:28 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:39:28 --> Utf8 Class Initialized
INFO - 2025-02-28 18:39:28 --> URI Class Initialized
DEBUG - 2025-02-28 18:39:28 --> No URI present. Default controller set.
INFO - 2025-02-28 18:39:28 --> Router Class Initialized
INFO - 2025-02-28 18:39:28 --> Output Class Initialized
INFO - 2025-02-28 18:39:28 --> Security Class Initialized
DEBUG - 2025-02-28 18:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:39:28 --> Input Class Initialized
INFO - 2025-02-28 18:39:28 --> Language Class Initialized
INFO - 2025-02-28 18:39:28 --> Loader Class Initialized
INFO - 2025-02-28 18:39:28 --> Helper loaded: url_helper
INFO - 2025-02-28 18:39:28 --> Helper loaded: file_helper
INFO - 2025-02-28 18:39:28 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:39:28 --> Database Driver Class Initialized
INFO - 2025-02-28 18:39:28 --> Email Class Initialized
INFO - 2025-02-28 18:39:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:39:28 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:39:28 --> Upload Class Initialized
INFO - 2025-02-28 18:39:28 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:39:28 --> Controller Class Initialized
INFO - 2025-02-28 18:39:28 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 18:39:28 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 18:39:28 --> File loaded: C:\wamp64\www\fubkportal\application\views\login.php
INFO - 2025-02-28 18:39:28 --> Final output sent to browser
DEBUG - 2025-02-28 18:39:28 --> Total execution time: 0.0425
INFO - 2025-02-28 18:39:40 --> Config Class Initialized
INFO - 2025-02-28 18:39:40 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:39:40 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:39:40 --> Utf8 Class Initialized
INFO - 2025-02-28 18:39:40 --> URI Class Initialized
DEBUG - 2025-02-28 18:39:40 --> No URI present. Default controller set.
INFO - 2025-02-28 18:39:40 --> Router Class Initialized
INFO - 2025-02-28 18:39:40 --> Output Class Initialized
INFO - 2025-02-28 18:39:40 --> Security Class Initialized
DEBUG - 2025-02-28 18:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:39:40 --> Input Class Initialized
INFO - 2025-02-28 18:39:40 --> Language Class Initialized
INFO - 2025-02-28 18:39:40 --> Loader Class Initialized
INFO - 2025-02-28 18:39:40 --> Helper loaded: url_helper
INFO - 2025-02-28 18:39:40 --> Helper loaded: file_helper
INFO - 2025-02-28 18:39:40 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:39:40 --> Database Driver Class Initialized
INFO - 2025-02-28 18:39:40 --> Email Class Initialized
INFO - 2025-02-28 18:39:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:39:40 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:39:40 --> Upload Class Initialized
INFO - 2025-02-28 18:39:40 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:39:40 --> Controller Class Initialized
INFO - 2025-02-28 18:39:40 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 18:39:40 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 18:39:40 --> File loaded: C:\wamp64\www\fubkportal\application\views\login.php
INFO - 2025-02-28 18:39:40 --> Final output sent to browser
DEBUG - 2025-02-28 18:39:40 --> Total execution time: 0.0311
INFO - 2025-02-28 18:41:23 --> Config Class Initialized
INFO - 2025-02-28 18:41:23 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:41:23 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:41:23 --> Utf8 Class Initialized
INFO - 2025-02-28 18:41:23 --> URI Class Initialized
DEBUG - 2025-02-28 18:41:23 --> No URI present. Default controller set.
INFO - 2025-02-28 18:41:23 --> Router Class Initialized
INFO - 2025-02-28 18:41:23 --> Output Class Initialized
INFO - 2025-02-28 18:41:23 --> Security Class Initialized
DEBUG - 2025-02-28 18:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:41:23 --> Input Class Initialized
INFO - 2025-02-28 18:41:23 --> Language Class Initialized
INFO - 2025-02-28 18:41:23 --> Loader Class Initialized
INFO - 2025-02-28 18:41:23 --> Helper loaded: url_helper
INFO - 2025-02-28 18:41:23 --> Helper loaded: file_helper
INFO - 2025-02-28 18:41:23 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:41:23 --> Database Driver Class Initialized
INFO - 2025-02-28 18:41:23 --> Email Class Initialized
INFO - 2025-02-28 18:41:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:41:23 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:41:23 --> Upload Class Initialized
INFO - 2025-02-28 18:41:23 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:41:23 --> Controller Class Initialized
INFO - 2025-02-28 18:41:23 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 18:41:23 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 18:41:23 --> File loaded: C:\wamp64\www\fubkportal\application\views\login.php
INFO - 2025-02-28 18:41:23 --> Final output sent to browser
DEBUG - 2025-02-28 18:41:23 --> Total execution time: 0.0275
INFO - 2025-02-28 18:41:41 --> Config Class Initialized
INFO - 2025-02-28 18:41:41 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:41:41 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:41:41 --> Utf8 Class Initialized
INFO - 2025-02-28 18:41:41 --> URI Class Initialized
DEBUG - 2025-02-28 18:41:41 --> No URI present. Default controller set.
INFO - 2025-02-28 18:41:41 --> Router Class Initialized
INFO - 2025-02-28 18:41:41 --> Output Class Initialized
INFO - 2025-02-28 18:41:41 --> Security Class Initialized
DEBUG - 2025-02-28 18:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:41:41 --> Input Class Initialized
INFO - 2025-02-28 18:41:41 --> Language Class Initialized
INFO - 2025-02-28 18:41:41 --> Loader Class Initialized
INFO - 2025-02-28 18:41:41 --> Helper loaded: url_helper
INFO - 2025-02-28 18:41:41 --> Helper loaded: file_helper
INFO - 2025-02-28 18:41:41 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:41:41 --> Database Driver Class Initialized
INFO - 2025-02-28 18:41:41 --> Email Class Initialized
INFO - 2025-02-28 18:41:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:41:41 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:41:41 --> Upload Class Initialized
INFO - 2025-02-28 18:41:41 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:41:41 --> Controller Class Initialized
INFO - 2025-02-28 18:41:41 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 18:41:41 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 18:41:41 --> File loaded: C:\wamp64\www\fubkportal\application\views\login.php
INFO - 2025-02-28 18:41:41 --> Final output sent to browser
DEBUG - 2025-02-28 18:41:41 --> Total execution time: 0.0541
INFO - 2025-02-28 18:41:41 --> Config Class Initialized
INFO - 2025-02-28 18:41:41 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:41:41 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:41:41 --> Utf8 Class Initialized
INFO - 2025-02-28 18:41:41 --> URI Class Initialized
INFO - 2025-02-28 18:41:41 --> Config Class Initialized
INFO - 2025-02-28 18:41:41 --> Hooks Class Initialized
INFO - 2025-02-28 18:41:41 --> Router Class Initialized
INFO - 2025-02-28 18:41:41 --> Config Class Initialized
DEBUG - 2025-02-28 18:41:41 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:41:41 --> Output Class Initialized
INFO - 2025-02-28 18:41:41 --> Hooks Class Initialized
INFO - 2025-02-28 18:41:41 --> Utf8 Class Initialized
INFO - 2025-02-28 18:41:41 --> Security Class Initialized
DEBUG - 2025-02-28 18:41:41 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:41:41 --> URI Class Initialized
DEBUG - 2025-02-28 18:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:41:41 --> Utf8 Class Initialized
INFO - 2025-02-28 18:41:41 --> Input Class Initialized
INFO - 2025-02-28 18:41:41 --> Router Class Initialized
INFO - 2025-02-28 18:41:41 --> Language Class Initialized
INFO - 2025-02-28 18:41:41 --> URI Class Initialized
INFO - 2025-02-28 18:41:41 --> Output Class Initialized
ERROR - 2025-02-28 18:41:41 --> 404 Page Not Found: Localhost/fubkportal
INFO - 2025-02-28 18:41:41 --> Router Class Initialized
INFO - 2025-02-28 18:41:41 --> Security Class Initialized
DEBUG - 2025-02-28 18:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:41:41 --> Output Class Initialized
INFO - 2025-02-28 18:41:41 --> Input Class Initialized
INFO - 2025-02-28 18:41:41 --> Security Class Initialized
INFO - 2025-02-28 18:41:41 --> Language Class Initialized
DEBUG - 2025-02-28 18:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:41:41 --> Input Class Initialized
ERROR - 2025-02-28 18:41:41 --> 404 Page Not Found: Localhost/fubkportal
INFO - 2025-02-28 18:41:41 --> Language Class Initialized
ERROR - 2025-02-28 18:41:41 --> 404 Page Not Found: Localhost/fubkportal
INFO - 2025-02-28 18:41:43 --> Config Class Initialized
INFO - 2025-02-28 18:41:43 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:41:43 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:41:43 --> Utf8 Class Initialized
INFO - 2025-02-28 18:41:43 --> URI Class Initialized
INFO - 2025-02-28 18:41:43 --> Router Class Initialized
INFO - 2025-02-28 18:41:43 --> Output Class Initialized
INFO - 2025-02-28 18:41:43 --> Security Class Initialized
DEBUG - 2025-02-28 18:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:41:43 --> Input Class Initialized
INFO - 2025-02-28 18:41:43 --> Language Class Initialized
ERROR - 2025-02-28 18:41:43 --> 404 Page Not Found: Localhost/fubkportal
INFO - 2025-02-28 18:41:56 --> Config Class Initialized
INFO - 2025-02-28 18:41:56 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:41:56 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:41:56 --> Utf8 Class Initialized
INFO - 2025-02-28 18:41:56 --> URI Class Initialized
DEBUG - 2025-02-28 18:41:56 --> No URI present. Default controller set.
INFO - 2025-02-28 18:41:56 --> Router Class Initialized
INFO - 2025-02-28 18:41:56 --> Output Class Initialized
INFO - 2025-02-28 18:41:56 --> Security Class Initialized
DEBUG - 2025-02-28 18:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:41:56 --> Input Class Initialized
INFO - 2025-02-28 18:41:56 --> Language Class Initialized
INFO - 2025-02-28 18:41:56 --> Loader Class Initialized
INFO - 2025-02-28 18:41:56 --> Helper loaded: url_helper
INFO - 2025-02-28 18:41:56 --> Helper loaded: file_helper
INFO - 2025-02-28 18:41:56 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:41:56 --> Database Driver Class Initialized
INFO - 2025-02-28 18:41:56 --> Email Class Initialized
INFO - 2025-02-28 18:41:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:41:56 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:41:56 --> Upload Class Initialized
INFO - 2025-02-28 18:41:56 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:41:56 --> Controller Class Initialized
INFO - 2025-02-28 18:41:56 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 18:41:56 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 18:41:56 --> File loaded: C:\wamp64\www\fubkportal\application\views\login.php
INFO - 2025-02-28 18:41:56 --> Final output sent to browser
DEBUG - 2025-02-28 18:41:56 --> Total execution time: 0.0373
INFO - 2025-02-28 18:42:05 --> Config Class Initialized
INFO - 2025-02-28 18:42:05 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:42:05 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:42:05 --> Utf8 Class Initialized
INFO - 2025-02-28 18:42:05 --> URI Class Initialized
INFO - 2025-02-28 18:42:05 --> Router Class Initialized
INFO - 2025-02-28 18:42:05 --> Output Class Initialized
INFO - 2025-02-28 18:42:05 --> Security Class Initialized
DEBUG - 2025-02-28 18:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:42:05 --> Input Class Initialized
INFO - 2025-02-28 18:42:05 --> Language Class Initialized
ERROR - 2025-02-28 18:42:05 --> 404 Page Not Found: Localhost/fubkportal
INFO - 2025-02-28 18:43:30 --> Config Class Initialized
INFO - 2025-02-28 18:43:30 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:43:30 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:43:30 --> Utf8 Class Initialized
INFO - 2025-02-28 18:43:30 --> URI Class Initialized
DEBUG - 2025-02-28 18:43:30 --> No URI present. Default controller set.
INFO - 2025-02-28 18:43:30 --> Router Class Initialized
INFO - 2025-02-28 18:43:30 --> Output Class Initialized
INFO - 2025-02-28 18:43:30 --> Security Class Initialized
DEBUG - 2025-02-28 18:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:43:30 --> Input Class Initialized
INFO - 2025-02-28 18:43:30 --> Language Class Initialized
INFO - 2025-02-28 18:43:30 --> Loader Class Initialized
INFO - 2025-02-28 18:43:30 --> Helper loaded: url_helper
INFO - 2025-02-28 18:43:30 --> Helper loaded: file_helper
INFO - 2025-02-28 18:43:30 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:43:30 --> Database Driver Class Initialized
INFO - 2025-02-28 18:43:30 --> Email Class Initialized
INFO - 2025-02-28 18:43:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:43:30 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:43:30 --> Upload Class Initialized
INFO - 2025-02-28 18:43:30 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:43:30 --> Controller Class Initialized
INFO - 2025-02-28 18:43:30 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 18:43:30 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 18:43:30 --> File loaded: C:\wamp64\www\fubkportal\application\views\login.php
INFO - 2025-02-28 18:43:30 --> Final output sent to browser
DEBUG - 2025-02-28 18:43:30 --> Total execution time: 0.0475
INFO - 2025-02-28 18:43:30 --> Config Class Initialized
INFO - 2025-02-28 18:43:30 --> Hooks Class Initialized
INFO - 2025-02-28 18:43:30 --> Config Class Initialized
DEBUG - 2025-02-28 18:43:30 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:43:30 --> Hooks Class Initialized
INFO - 2025-02-28 18:43:30 --> Utf8 Class Initialized
DEBUG - 2025-02-28 18:43:30 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:43:30 --> URI Class Initialized
INFO - 2025-02-28 18:43:30 --> Utf8 Class Initialized
INFO - 2025-02-28 18:43:30 --> Config Class Initialized
INFO - 2025-02-28 18:43:30 --> Hooks Class Initialized
INFO - 2025-02-28 18:43:30 --> Router Class Initialized
INFO - 2025-02-28 18:43:30 --> URI Class Initialized
DEBUG - 2025-02-28 18:43:30 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:43:30 --> Utf8 Class Initialized
INFO - 2025-02-28 18:43:30 --> Output Class Initialized
INFO - 2025-02-28 18:43:30 --> Router Class Initialized
INFO - 2025-02-28 18:43:30 --> URI Class Initialized
INFO - 2025-02-28 18:43:30 --> Security Class Initialized
INFO - 2025-02-28 18:43:30 --> Output Class Initialized
DEBUG - 2025-02-28 18:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:43:30 --> Input Class Initialized
INFO - 2025-02-28 18:43:30 --> Router Class Initialized
INFO - 2025-02-28 18:43:30 --> Security Class Initialized
INFO - 2025-02-28 18:43:30 --> Language Class Initialized
INFO - 2025-02-28 18:43:30 --> Output Class Initialized
DEBUG - 2025-02-28 18:43:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2025-02-28 18:43:30 --> 404 Page Not Found: Localhost/fubkportal
INFO - 2025-02-28 18:43:30 --> Input Class Initialized
INFO - 2025-02-28 18:43:30 --> Security Class Initialized
INFO - 2025-02-28 18:43:30 --> Language Class Initialized
DEBUG - 2025-02-28 18:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:43:30 --> Input Class Initialized
ERROR - 2025-02-28 18:43:30 --> 404 Page Not Found: Localhost/fubkportal
INFO - 2025-02-28 18:43:30 --> Language Class Initialized
ERROR - 2025-02-28 18:43:30 --> 404 Page Not Found: Localhost/fubkportal
INFO - 2025-02-28 18:43:44 --> Config Class Initialized
INFO - 2025-02-28 18:43:44 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:43:44 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:43:44 --> Utf8 Class Initialized
INFO - 2025-02-28 18:43:44 --> URI Class Initialized
DEBUG - 2025-02-28 18:43:44 --> No URI present. Default controller set.
INFO - 2025-02-28 18:43:44 --> Router Class Initialized
INFO - 2025-02-28 18:43:44 --> Output Class Initialized
INFO - 2025-02-28 18:43:44 --> Security Class Initialized
DEBUG - 2025-02-28 18:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:43:44 --> Input Class Initialized
INFO - 2025-02-28 18:43:44 --> Language Class Initialized
INFO - 2025-02-28 18:43:44 --> Loader Class Initialized
INFO - 2025-02-28 18:43:44 --> Helper loaded: url_helper
INFO - 2025-02-28 18:43:44 --> Helper loaded: file_helper
INFO - 2025-02-28 18:43:44 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:43:44 --> Database Driver Class Initialized
INFO - 2025-02-28 18:43:44 --> Email Class Initialized
INFO - 2025-02-28 18:43:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:43:44 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:43:44 --> Upload Class Initialized
INFO - 2025-02-28 18:43:44 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:43:44 --> Controller Class Initialized
INFO - 2025-02-28 18:43:44 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 18:43:44 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 18:43:44 --> File loaded: C:\wamp64\www\fubkportal\application\views\login.php
INFO - 2025-02-28 18:43:44 --> Final output sent to browser
DEBUG - 2025-02-28 18:43:44 --> Total execution time: 0.0352
INFO - 2025-02-28 18:43:54 --> Config Class Initialized
INFO - 2025-02-28 18:43:54 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:43:54 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:43:54 --> Utf8 Class Initialized
INFO - 2025-02-28 18:43:54 --> URI Class Initialized
INFO - 2025-02-28 18:43:54 --> Router Class Initialized
INFO - 2025-02-28 18:43:54 --> Output Class Initialized
INFO - 2025-02-28 18:43:54 --> Security Class Initialized
DEBUG - 2025-02-28 18:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:43:54 --> Input Class Initialized
INFO - 2025-02-28 18:43:54 --> Language Class Initialized
ERROR - 2025-02-28 18:43:54 --> 404 Page Not Found: Localhost/fubkportal
INFO - 2025-02-28 18:44:03 --> Config Class Initialized
INFO - 2025-02-28 18:44:03 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:44:03 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:44:03 --> Utf8 Class Initialized
INFO - 2025-02-28 18:44:03 --> URI Class Initialized
INFO - 2025-02-28 18:44:03 --> Router Class Initialized
INFO - 2025-02-28 18:44:03 --> Output Class Initialized
INFO - 2025-02-28 18:44:03 --> Security Class Initialized
DEBUG - 2025-02-28 18:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:44:03 --> Input Class Initialized
INFO - 2025-02-28 18:44:03 --> Language Class Initialized
ERROR - 2025-02-28 18:44:03 --> 404 Page Not Found: Localhost/fubkportal
INFO - 2025-02-28 18:44:37 --> Config Class Initialized
INFO - 2025-02-28 18:44:37 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:44:37 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:44:37 --> Utf8 Class Initialized
INFO - 2025-02-28 18:44:37 --> URI Class Initialized
DEBUG - 2025-02-28 18:44:37 --> No URI present. Default controller set.
INFO - 2025-02-28 18:44:37 --> Router Class Initialized
INFO - 2025-02-28 18:44:37 --> Output Class Initialized
INFO - 2025-02-28 18:44:37 --> Security Class Initialized
DEBUG - 2025-02-28 18:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:44:37 --> Input Class Initialized
INFO - 2025-02-28 18:44:37 --> Language Class Initialized
INFO - 2025-02-28 18:44:37 --> Loader Class Initialized
INFO - 2025-02-28 18:44:37 --> Helper loaded: url_helper
INFO - 2025-02-28 18:44:37 --> Helper loaded: file_helper
INFO - 2025-02-28 18:44:37 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:44:37 --> Database Driver Class Initialized
INFO - 2025-02-28 18:44:37 --> Email Class Initialized
INFO - 2025-02-28 18:44:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:44:37 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:44:37 --> Upload Class Initialized
INFO - 2025-02-28 18:44:37 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:44:37 --> Controller Class Initialized
INFO - 2025-02-28 18:44:37 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 18:44:37 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 18:44:37 --> File loaded: C:\wamp64\www\fubkportal\application\views\login.php
INFO - 2025-02-28 18:44:37 --> Final output sent to browser
DEBUG - 2025-02-28 18:44:37 --> Total execution time: 0.0323
INFO - 2025-02-28 18:47:45 --> Config Class Initialized
INFO - 2025-02-28 18:47:45 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:47:45 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:47:45 --> Utf8 Class Initialized
INFO - 2025-02-28 18:47:45 --> URI Class Initialized
DEBUG - 2025-02-28 18:47:45 --> No URI present. Default controller set.
INFO - 2025-02-28 18:47:45 --> Router Class Initialized
INFO - 2025-02-28 18:47:45 --> Output Class Initialized
INFO - 2025-02-28 18:47:45 --> Security Class Initialized
DEBUG - 2025-02-28 18:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:47:45 --> Input Class Initialized
INFO - 2025-02-28 18:47:45 --> Language Class Initialized
INFO - 2025-02-28 18:47:45 --> Loader Class Initialized
INFO - 2025-02-28 18:47:45 --> Helper loaded: url_helper
INFO - 2025-02-28 18:47:45 --> Helper loaded: file_helper
INFO - 2025-02-28 18:47:45 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:47:45 --> Database Driver Class Initialized
INFO - 2025-02-28 18:47:45 --> Email Class Initialized
INFO - 2025-02-28 18:47:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:47:45 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:47:45 --> Upload Class Initialized
INFO - 2025-02-28 18:47:45 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:47:45 --> Controller Class Initialized
INFO - 2025-02-28 18:47:45 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 18:47:45 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 18:47:45 --> File loaded: C:\wamp64\www\fubkportal\application\views\login.php
INFO - 2025-02-28 18:47:45 --> Final output sent to browser
DEBUG - 2025-02-28 18:47:45 --> Total execution time: 0.0372
INFO - 2025-02-28 18:47:45 --> Config Class Initialized
INFO - 2025-02-28 18:47:45 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:47:45 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:47:45 --> Utf8 Class Initialized
INFO - 2025-02-28 18:47:45 --> URI Class Initialized
INFO - 2025-02-28 18:47:45 --> Router Class Initialized
INFO - 2025-02-28 18:47:45 --> Config Class Initialized
INFO - 2025-02-28 18:47:45 --> Hooks Class Initialized
INFO - 2025-02-28 18:47:45 --> Output Class Initialized
DEBUG - 2025-02-28 18:47:45 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:47:45 --> Utf8 Class Initialized
INFO - 2025-02-28 18:47:45 --> Security Class Initialized
INFO - 2025-02-28 18:47:45 --> URI Class Initialized
DEBUG - 2025-02-28 18:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:47:45 --> Router Class Initialized
INFO - 2025-02-28 18:47:45 --> Input Class Initialized
INFO - 2025-02-28 18:47:45 --> Output Class Initialized
INFO - 2025-02-28 18:47:45 --> Language Class Initialized
INFO - 2025-02-28 18:47:45 --> Security Class Initialized
ERROR - 2025-02-28 18:47:45 --> 404 Page Not Found: Localhost/fubkportal
DEBUG - 2025-02-28 18:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:47:45 --> Input Class Initialized
INFO - 2025-02-28 18:47:45 --> Language Class Initialized
INFO - 2025-02-28 18:47:45 --> Config Class Initialized
INFO - 2025-02-28 18:47:45 --> Hooks Class Initialized
ERROR - 2025-02-28 18:47:45 --> 404 Page Not Found: Localhost/fubkportal
DEBUG - 2025-02-28 18:47:45 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:47:45 --> Utf8 Class Initialized
INFO - 2025-02-28 18:47:45 --> URI Class Initialized
INFO - 2025-02-28 18:47:45 --> Router Class Initialized
INFO - 2025-02-28 18:47:45 --> Output Class Initialized
INFO - 2025-02-28 18:47:45 --> Security Class Initialized
DEBUG - 2025-02-28 18:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:47:45 --> Input Class Initialized
INFO - 2025-02-28 18:47:45 --> Language Class Initialized
ERROR - 2025-02-28 18:47:45 --> 404 Page Not Found: Localhost/fubkportal
INFO - 2025-02-28 18:47:53 --> Config Class Initialized
INFO - 2025-02-28 18:47:53 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:47:53 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:47:53 --> Utf8 Class Initialized
INFO - 2025-02-28 18:47:53 --> URI Class Initialized
INFO - 2025-02-28 18:47:53 --> Router Class Initialized
INFO - 2025-02-28 18:47:53 --> Output Class Initialized
INFO - 2025-02-28 18:47:53 --> Security Class Initialized
DEBUG - 2025-02-28 18:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:47:53 --> Input Class Initialized
INFO - 2025-02-28 18:47:53 --> Language Class Initialized
ERROR - 2025-02-28 18:47:53 --> 404 Page Not Found: Localhost/fubkportal
INFO - 2025-02-28 18:47:58 --> Config Class Initialized
INFO - 2025-02-28 18:47:58 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:47:58 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:47:58 --> Utf8 Class Initialized
INFO - 2025-02-28 18:47:58 --> URI Class Initialized
DEBUG - 2025-02-28 18:47:58 --> No URI present. Default controller set.
INFO - 2025-02-28 18:47:58 --> Router Class Initialized
INFO - 2025-02-28 18:47:58 --> Output Class Initialized
INFO - 2025-02-28 18:47:58 --> Security Class Initialized
DEBUG - 2025-02-28 18:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:47:58 --> Input Class Initialized
INFO - 2025-02-28 18:47:58 --> Language Class Initialized
INFO - 2025-02-28 18:47:58 --> Loader Class Initialized
INFO - 2025-02-28 18:47:58 --> Helper loaded: url_helper
INFO - 2025-02-28 18:47:58 --> Helper loaded: file_helper
INFO - 2025-02-28 18:47:58 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:47:58 --> Database Driver Class Initialized
INFO - 2025-02-28 18:47:58 --> Email Class Initialized
INFO - 2025-02-28 18:47:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:47:58 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:47:58 --> Upload Class Initialized
INFO - 2025-02-28 18:47:58 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:47:58 --> Controller Class Initialized
INFO - 2025-02-28 18:47:58 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 18:47:58 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 18:47:58 --> File loaded: C:\wamp64\www\fubkportal\application\views\login.php
INFO - 2025-02-28 18:47:58 --> Final output sent to browser
DEBUG - 2025-02-28 18:47:58 --> Total execution time: 0.0390
INFO - 2025-02-28 18:49:44 --> Config Class Initialized
INFO - 2025-02-28 18:49:44 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:49:44 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:49:44 --> Utf8 Class Initialized
INFO - 2025-02-28 18:49:44 --> URI Class Initialized
DEBUG - 2025-02-28 18:49:44 --> No URI present. Default controller set.
INFO - 2025-02-28 18:49:44 --> Router Class Initialized
INFO - 2025-02-28 18:49:44 --> Output Class Initialized
INFO - 2025-02-28 18:49:44 --> Security Class Initialized
DEBUG - 2025-02-28 18:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:49:44 --> Input Class Initialized
INFO - 2025-02-28 18:49:44 --> Language Class Initialized
INFO - 2025-02-28 18:49:44 --> Loader Class Initialized
INFO - 2025-02-28 18:49:44 --> Helper loaded: url_helper
INFO - 2025-02-28 18:49:44 --> Helper loaded: file_helper
INFO - 2025-02-28 18:49:44 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:49:44 --> Database Driver Class Initialized
INFO - 2025-02-28 18:49:44 --> Email Class Initialized
INFO - 2025-02-28 18:49:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:49:44 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:49:44 --> Upload Class Initialized
INFO - 2025-02-28 18:49:44 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:49:44 --> Controller Class Initialized
INFO - 2025-02-28 18:49:44 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 18:49:44 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 18:49:44 --> File loaded: C:\wamp64\www\fubkportal\application\views\login.php
INFO - 2025-02-28 18:49:44 --> Final output sent to browser
DEBUG - 2025-02-28 18:49:44 --> Total execution time: 0.0208
INFO - 2025-02-28 18:49:52 --> Config Class Initialized
INFO - 2025-02-28 18:49:52 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:49:52 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:49:52 --> Utf8 Class Initialized
INFO - 2025-02-28 18:49:52 --> URI Class Initialized
DEBUG - 2025-02-28 18:49:52 --> No URI present. Default controller set.
INFO - 2025-02-28 18:49:52 --> Router Class Initialized
INFO - 2025-02-28 18:49:52 --> Output Class Initialized
INFO - 2025-02-28 18:49:52 --> Security Class Initialized
DEBUG - 2025-02-28 18:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:49:52 --> Input Class Initialized
INFO - 2025-02-28 18:49:52 --> Language Class Initialized
INFO - 2025-02-28 18:49:52 --> Loader Class Initialized
INFO - 2025-02-28 18:49:52 --> Helper loaded: url_helper
INFO - 2025-02-28 18:49:52 --> Helper loaded: file_helper
INFO - 2025-02-28 18:49:52 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:49:52 --> Database Driver Class Initialized
INFO - 2025-02-28 18:49:52 --> Email Class Initialized
INFO - 2025-02-28 18:49:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:49:52 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:49:52 --> Upload Class Initialized
INFO - 2025-02-28 18:49:52 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:49:52 --> Controller Class Initialized
INFO - 2025-02-28 18:49:52 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 18:49:52 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 18:49:52 --> File loaded: C:\wamp64\www\fubkportal\application\views\login.php
INFO - 2025-02-28 18:49:52 --> Final output sent to browser
DEBUG - 2025-02-28 18:49:52 --> Total execution time: 0.0514
INFO - 2025-02-28 18:52:57 --> Config Class Initialized
INFO - 2025-02-28 18:52:57 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:52:57 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:52:57 --> Utf8 Class Initialized
INFO - 2025-02-28 18:52:57 --> URI Class Initialized
DEBUG - 2025-02-28 18:52:57 --> No URI present. Default controller set.
INFO - 2025-02-28 18:52:57 --> Router Class Initialized
INFO - 2025-02-28 18:52:57 --> Output Class Initialized
INFO - 2025-02-28 18:52:57 --> Security Class Initialized
DEBUG - 2025-02-28 18:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:52:57 --> Input Class Initialized
INFO - 2025-02-28 18:52:57 --> Language Class Initialized
INFO - 2025-02-28 18:52:57 --> Loader Class Initialized
INFO - 2025-02-28 18:52:57 --> Helper loaded: url_helper
INFO - 2025-02-28 18:52:57 --> Helper loaded: file_helper
INFO - 2025-02-28 18:52:57 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:52:57 --> Database Driver Class Initialized
INFO - 2025-02-28 18:52:57 --> Email Class Initialized
INFO - 2025-02-28 18:52:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:52:57 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:52:57 --> Upload Class Initialized
INFO - 2025-02-28 18:52:57 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:52:57 --> Controller Class Initialized
INFO - 2025-02-28 18:52:57 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 18:52:57 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 18:52:57 --> File loaded: C:\wamp64\www\fubkportal\application\views\login.php
INFO - 2025-02-28 18:52:57 --> Final output sent to browser
DEBUG - 2025-02-28 18:52:57 --> Total execution time: 0.0506
INFO - 2025-02-28 18:53:10 --> Config Class Initialized
INFO - 2025-02-28 18:53:10 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:53:10 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:53:10 --> Utf8 Class Initialized
INFO - 2025-02-28 18:53:10 --> URI Class Initialized
DEBUG - 2025-02-28 18:53:10 --> No URI present. Default controller set.
INFO - 2025-02-28 18:53:10 --> Router Class Initialized
INFO - 2025-02-28 18:53:10 --> Output Class Initialized
INFO - 2025-02-28 18:53:10 --> Security Class Initialized
DEBUG - 2025-02-28 18:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:53:10 --> Input Class Initialized
INFO - 2025-02-28 18:53:10 --> Language Class Initialized
INFO - 2025-02-28 18:53:10 --> Loader Class Initialized
INFO - 2025-02-28 18:53:10 --> Helper loaded: url_helper
INFO - 2025-02-28 18:53:10 --> Helper loaded: file_helper
INFO - 2025-02-28 18:53:10 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:53:10 --> Database Driver Class Initialized
INFO - 2025-02-28 18:53:10 --> Email Class Initialized
INFO - 2025-02-28 18:53:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:53:10 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:53:10 --> Upload Class Initialized
INFO - 2025-02-28 18:53:10 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:53:10 --> Controller Class Initialized
INFO - 2025-02-28 18:53:10 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 18:53:10 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 18:53:10 --> File loaded: C:\wamp64\www\fubkportal\application\views\login.php
INFO - 2025-02-28 18:53:10 --> Final output sent to browser
DEBUG - 2025-02-28 18:53:10 --> Total execution time: 0.0489
INFO - 2025-02-28 18:55:39 --> Config Class Initialized
INFO - 2025-02-28 18:55:39 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:55:39 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:55:39 --> Utf8 Class Initialized
INFO - 2025-02-28 18:55:39 --> URI Class Initialized
INFO - 2025-02-28 18:55:39 --> Router Class Initialized
INFO - 2025-02-28 18:55:39 --> Output Class Initialized
INFO - 2025-02-28 18:55:39 --> Security Class Initialized
DEBUG - 2025-02-28 18:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:55:39 --> Input Class Initialized
INFO - 2025-02-28 18:55:39 --> Language Class Initialized
INFO - 2025-02-28 18:55:39 --> Loader Class Initialized
INFO - 2025-02-28 18:55:39 --> Helper loaded: url_helper
INFO - 2025-02-28 18:55:39 --> Helper loaded: file_helper
INFO - 2025-02-28 18:55:39 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:55:39 --> Database Driver Class Initialized
INFO - 2025-02-28 18:55:39 --> Email Class Initialized
INFO - 2025-02-28 18:55:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:55:39 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:55:39 --> Upload Class Initialized
INFO - 2025-02-28 18:55:39 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:55:39 --> Controller Class Initialized
INFO - 2025-02-28 18:55:39 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 18:55:39 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 18:55:44 --> Config Class Initialized
INFO - 2025-02-28 18:55:44 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:55:44 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:55:44 --> Utf8 Class Initialized
INFO - 2025-02-28 18:55:44 --> URI Class Initialized
INFO - 2025-02-28 18:55:44 --> Router Class Initialized
INFO - 2025-02-28 18:55:44 --> Output Class Initialized
INFO - 2025-02-28 18:55:44 --> Security Class Initialized
DEBUG - 2025-02-28 18:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:55:44 --> Input Class Initialized
INFO - 2025-02-28 18:55:44 --> Language Class Initialized
INFO - 2025-02-28 18:55:44 --> Loader Class Initialized
INFO - 2025-02-28 18:55:44 --> Helper loaded: url_helper
INFO - 2025-02-28 18:55:44 --> Helper loaded: file_helper
INFO - 2025-02-28 18:55:44 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:55:44 --> Database Driver Class Initialized
INFO - 2025-02-28 18:55:44 --> Email Class Initialized
INFO - 2025-02-28 18:55:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:55:44 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:55:44 --> Upload Class Initialized
INFO - 2025-02-28 18:55:44 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:55:44 --> Controller Class Initialized
INFO - 2025-02-28 18:55:44 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 18:55:44 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 18:55:44 --> File loaded: C:\wamp64\www\fubkportal\application\views\login.php
INFO - 2025-02-28 18:55:44 --> Final output sent to browser
DEBUG - 2025-02-28 18:55:44 --> Total execution time: 0.0378
INFO - 2025-02-28 18:56:08 --> Config Class Initialized
INFO - 2025-02-28 18:56:08 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:56:08 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:56:08 --> Utf8 Class Initialized
INFO - 2025-02-28 18:56:08 --> URI Class Initialized
INFO - 2025-02-28 18:56:08 --> Router Class Initialized
INFO - 2025-02-28 18:56:08 --> Output Class Initialized
INFO - 2025-02-28 18:56:08 --> Security Class Initialized
DEBUG - 2025-02-28 18:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:56:08 --> Input Class Initialized
INFO - 2025-02-28 18:56:08 --> Language Class Initialized
INFO - 2025-02-28 18:56:08 --> Loader Class Initialized
INFO - 2025-02-28 18:56:08 --> Helper loaded: url_helper
INFO - 2025-02-28 18:56:08 --> Helper loaded: file_helper
INFO - 2025-02-28 18:56:08 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:56:08 --> Database Driver Class Initialized
INFO - 2025-02-28 18:56:08 --> Email Class Initialized
INFO - 2025-02-28 18:56:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:56:08 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:56:08 --> Upload Class Initialized
INFO - 2025-02-28 18:56:08 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:56:08 --> Controller Class Initialized
INFO - 2025-02-28 18:56:08 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 18:56:08 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 18:56:10 --> Config Class Initialized
INFO - 2025-02-28 18:56:10 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:56:10 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:56:10 --> Utf8 Class Initialized
INFO - 2025-02-28 18:56:10 --> URI Class Initialized
INFO - 2025-02-28 18:56:10 --> Router Class Initialized
INFO - 2025-02-28 18:56:10 --> Output Class Initialized
INFO - 2025-02-28 18:56:10 --> Security Class Initialized
DEBUG - 2025-02-28 18:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:56:10 --> Input Class Initialized
INFO - 2025-02-28 18:56:10 --> Language Class Initialized
INFO - 2025-02-28 18:56:10 --> Loader Class Initialized
INFO - 2025-02-28 18:56:10 --> Helper loaded: url_helper
INFO - 2025-02-28 18:56:10 --> Helper loaded: file_helper
INFO - 2025-02-28 18:56:10 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:56:10 --> Database Driver Class Initialized
INFO - 2025-02-28 18:56:10 --> Email Class Initialized
INFO - 2025-02-28 18:56:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:56:10 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:56:10 --> Upload Class Initialized
INFO - 2025-02-28 18:56:10 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:56:10 --> Controller Class Initialized
INFO - 2025-02-28 18:56:10 --> Model "Staff_model" initialized
INFO - 2025-02-28 18:56:10 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/header.php
INFO - 2025-02-28 18:56:10 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/lside.php
INFO - 2025-02-28 18:56:10 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/pageheader.php
INFO - 2025-02-28 18:56:10 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/footer.php
INFO - 2025-02-28 18:56:10 --> File loaded: C:\wamp64\www\fubkportal\application\views\staff/index.php
INFO - 2025-02-28 18:56:10 --> Final output sent to browser
DEBUG - 2025-02-28 18:56:10 --> Total execution time: 0.0634
INFO - 2025-02-28 18:56:10 --> Config Class Initialized
INFO - 2025-02-28 18:56:10 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:56:10 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:56:10 --> Utf8 Class Initialized
INFO - 2025-02-28 18:56:10 --> URI Class Initialized
INFO - 2025-02-28 18:56:10 --> Router Class Initialized
INFO - 2025-02-28 18:56:10 --> Output Class Initialized
INFO - 2025-02-28 18:56:10 --> Security Class Initialized
DEBUG - 2025-02-28 18:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:56:10 --> Input Class Initialized
INFO - 2025-02-28 18:56:10 --> Language Class Initialized
ERROR - 2025-02-28 18:56:10 --> 404 Page Not Found: Passport/17b115107aaa1714fb2f01da83b832ab.jpg
INFO - 2025-02-28 18:56:50 --> Config Class Initialized
INFO - 2025-02-28 18:56:50 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:56:50 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:56:50 --> Utf8 Class Initialized
INFO - 2025-02-28 18:56:50 --> URI Class Initialized
INFO - 2025-02-28 18:56:50 --> Router Class Initialized
INFO - 2025-02-28 18:56:50 --> Output Class Initialized
INFO - 2025-02-28 18:56:50 --> Security Class Initialized
DEBUG - 2025-02-28 18:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:56:50 --> Input Class Initialized
INFO - 2025-02-28 18:56:50 --> Language Class Initialized
INFO - 2025-02-28 18:56:50 --> Loader Class Initialized
INFO - 2025-02-28 18:56:50 --> Helper loaded: url_helper
INFO - 2025-02-28 18:56:50 --> Helper loaded: file_helper
INFO - 2025-02-28 18:56:50 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:56:50 --> Database Driver Class Initialized
INFO - 2025-02-28 18:56:50 --> Email Class Initialized
INFO - 2025-02-28 18:56:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:56:50 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:56:50 --> Upload Class Initialized
INFO - 2025-02-28 18:56:50 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:56:50 --> Controller Class Initialized
INFO - 2025-02-28 18:56:50 --> Model "Staff_model" initialized
INFO - 2025-02-28 18:56:50 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/header.php
INFO - 2025-02-28 18:56:50 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/lside.php
INFO - 2025-02-28 18:56:50 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/pageheader.php
INFO - 2025-02-28 18:56:50 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/footer.php
INFO - 2025-02-28 18:56:50 --> File loaded: C:\wamp64\www\fubkportal\application\views\staff/index.php
INFO - 2025-02-28 18:56:50 --> Final output sent to browser
DEBUG - 2025-02-28 18:56:50 --> Total execution time: 0.0790
INFO - 2025-02-28 18:57:39 --> Config Class Initialized
INFO - 2025-02-28 18:57:39 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:57:39 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:57:39 --> Utf8 Class Initialized
INFO - 2025-02-28 18:57:39 --> URI Class Initialized
INFO - 2025-02-28 18:57:39 --> Router Class Initialized
INFO - 2025-02-28 18:57:39 --> Output Class Initialized
INFO - 2025-02-28 18:57:39 --> Security Class Initialized
DEBUG - 2025-02-28 18:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:57:39 --> Input Class Initialized
INFO - 2025-02-28 18:57:39 --> Language Class Initialized
INFO - 2025-02-28 18:57:39 --> Loader Class Initialized
INFO - 2025-02-28 18:57:39 --> Helper loaded: url_helper
INFO - 2025-02-28 18:57:39 --> Helper loaded: file_helper
INFO - 2025-02-28 18:57:39 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:57:39 --> Database Driver Class Initialized
INFO - 2025-02-28 18:57:39 --> Email Class Initialized
INFO - 2025-02-28 18:57:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:57:39 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:57:39 --> Upload Class Initialized
INFO - 2025-02-28 18:57:39 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:57:39 --> Controller Class Initialized
INFO - 2025-02-28 18:57:39 --> Model "Staff_model" initialized
INFO - 2025-02-28 18:57:39 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/header.php
INFO - 2025-02-28 18:57:39 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/lside.php
INFO - 2025-02-28 18:57:39 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/pageheader.php
INFO - 2025-02-28 18:57:39 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/footer.php
INFO - 2025-02-28 18:57:39 --> File loaded: C:\wamp64\www\fubkportal\application\views\staff/index.php
INFO - 2025-02-28 18:57:39 --> Final output sent to browser
DEBUG - 2025-02-28 18:57:39 --> Total execution time: 0.0261
INFO - 2025-02-28 18:57:39 --> Config Class Initialized
INFO - 2025-02-28 18:57:39 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:57:39 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:57:39 --> Utf8 Class Initialized
INFO - 2025-02-28 18:57:39 --> URI Class Initialized
INFO - 2025-02-28 18:57:39 --> Router Class Initialized
INFO - 2025-02-28 18:57:39 --> Output Class Initialized
INFO - 2025-02-28 18:57:39 --> Security Class Initialized
DEBUG - 2025-02-28 18:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:57:39 --> Input Class Initialized
INFO - 2025-02-28 18:57:39 --> Language Class Initialized
ERROR - 2025-02-28 18:57:39 --> 404 Page Not Found: Passport/17b115107aaa1714fb2f01da83b832ab.jpg
INFO - 2025-02-28 18:57:43 --> Config Class Initialized
INFO - 2025-02-28 18:57:43 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:57:43 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:57:43 --> Utf8 Class Initialized
INFO - 2025-02-28 18:57:43 --> URI Class Initialized
INFO - 2025-02-28 18:57:43 --> Router Class Initialized
INFO - 2025-02-28 18:57:43 --> Output Class Initialized
INFO - 2025-02-28 18:57:43 --> Security Class Initialized
DEBUG - 2025-02-28 18:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:57:43 --> Input Class Initialized
INFO - 2025-02-28 18:57:43 --> Language Class Initialized
INFO - 2025-02-28 18:57:43 --> Loader Class Initialized
INFO - 2025-02-28 18:57:43 --> Helper loaded: url_helper
INFO - 2025-02-28 18:57:43 --> Helper loaded: file_helper
INFO - 2025-02-28 18:57:43 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:57:43 --> Database Driver Class Initialized
INFO - 2025-02-28 18:57:43 --> Email Class Initialized
INFO - 2025-02-28 18:57:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:57:43 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:57:43 --> Upload Class Initialized
INFO - 2025-02-28 18:57:43 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:57:43 --> Controller Class Initialized
INFO - 2025-02-28 18:57:43 --> Model "Staff_model" initialized
INFO - 2025-02-28 18:57:43 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/header.php
INFO - 2025-02-28 18:57:43 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/lside.php
INFO - 2025-02-28 18:57:43 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/pageheader.php
INFO - 2025-02-28 18:57:43 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/footer.php
INFO - 2025-02-28 18:57:43 --> File loaded: C:\wamp64\www\fubkportal\application\views\staff/index.php
INFO - 2025-02-28 18:57:43 --> Final output sent to browser
DEBUG - 2025-02-28 18:57:43 --> Total execution time: 0.0471
INFO - 2025-02-28 18:59:28 --> Config Class Initialized
INFO - 2025-02-28 18:59:28 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:59:28 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:59:28 --> Utf8 Class Initialized
INFO - 2025-02-28 18:59:28 --> URI Class Initialized
DEBUG - 2025-02-28 18:59:28 --> No URI present. Default controller set.
INFO - 2025-02-28 18:59:28 --> Router Class Initialized
INFO - 2025-02-28 18:59:28 --> Output Class Initialized
INFO - 2025-02-28 18:59:28 --> Security Class Initialized
DEBUG - 2025-02-28 18:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:59:28 --> Input Class Initialized
INFO - 2025-02-28 18:59:28 --> Language Class Initialized
INFO - 2025-02-28 18:59:28 --> Loader Class Initialized
INFO - 2025-02-28 18:59:28 --> Helper loaded: url_helper
INFO - 2025-02-28 18:59:28 --> Helper loaded: file_helper
INFO - 2025-02-28 18:59:28 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:59:28 --> Database Driver Class Initialized
INFO - 2025-02-28 18:59:28 --> Email Class Initialized
INFO - 2025-02-28 18:59:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:59:28 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:59:28 --> Upload Class Initialized
INFO - 2025-02-28 18:59:28 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:59:28 --> Controller Class Initialized
INFO - 2025-02-28 18:59:28 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 18:59:28 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 18:59:28 --> File loaded: C:\wamp64\www\fubkportal\application\views\login.php
INFO - 2025-02-28 18:59:28 --> Final output sent to browser
DEBUG - 2025-02-28 18:59:28 --> Total execution time: 0.0299
INFO - 2025-02-28 18:59:54 --> Config Class Initialized
INFO - 2025-02-28 18:59:54 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:59:54 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:59:54 --> Utf8 Class Initialized
INFO - 2025-02-28 18:59:54 --> URI Class Initialized
INFO - 2025-02-28 18:59:54 --> Router Class Initialized
INFO - 2025-02-28 18:59:54 --> Output Class Initialized
INFO - 2025-02-28 18:59:54 --> Security Class Initialized
DEBUG - 2025-02-28 18:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:59:54 --> Input Class Initialized
INFO - 2025-02-28 18:59:54 --> Language Class Initialized
INFO - 2025-02-28 18:59:54 --> Loader Class Initialized
INFO - 2025-02-28 18:59:54 --> Helper loaded: url_helper
INFO - 2025-02-28 18:59:54 --> Helper loaded: file_helper
INFO - 2025-02-28 18:59:54 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:59:54 --> Database Driver Class Initialized
INFO - 2025-02-28 18:59:54 --> Email Class Initialized
INFO - 2025-02-28 18:59:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:59:54 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:59:54 --> Upload Class Initialized
INFO - 2025-02-28 18:59:54 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:59:54 --> Controller Class Initialized
INFO - 2025-02-28 18:59:54 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 18:59:54 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 18:59:55 --> Config Class Initialized
INFO - 2025-02-28 18:59:55 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:59:55 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:59:55 --> Utf8 Class Initialized
INFO - 2025-02-28 18:59:55 --> URI Class Initialized
INFO - 2025-02-28 18:59:55 --> Router Class Initialized
INFO - 2025-02-28 18:59:55 --> Output Class Initialized
INFO - 2025-02-28 18:59:55 --> Security Class Initialized
DEBUG - 2025-02-28 18:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:59:55 --> Input Class Initialized
INFO - 2025-02-28 18:59:55 --> Language Class Initialized
INFO - 2025-02-28 18:59:55 --> Loader Class Initialized
INFO - 2025-02-28 18:59:55 --> Helper loaded: url_helper
INFO - 2025-02-28 18:59:55 --> Helper loaded: file_helper
INFO - 2025-02-28 18:59:55 --> Helper loaded: jwt_helper
INFO - 2025-02-28 18:59:55 --> Database Driver Class Initialized
INFO - 2025-02-28 18:59:55 --> Email Class Initialized
INFO - 2025-02-28 18:59:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 18:59:55 --> PHPMailer loaded successfully
INFO - 2025-02-28 18:59:55 --> Upload Class Initialized
INFO - 2025-02-28 18:59:55 --> Model "Auth_model" initialized
INFO - 2025-02-28 18:59:55 --> Controller Class Initialized
INFO - 2025-02-28 18:59:55 --> Model "Staff_model" initialized
INFO - 2025-02-28 18:59:55 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/header.php
INFO - 2025-02-28 18:59:55 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/lside.php
INFO - 2025-02-28 18:59:55 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/pageheader.php
INFO - 2025-02-28 18:59:55 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/footer.php
INFO - 2025-02-28 18:59:55 --> File loaded: C:\wamp64\www\fubkportal\application\views\staff/index.php
INFO - 2025-02-28 18:59:55 --> Final output sent to browser
DEBUG - 2025-02-28 18:59:55 --> Total execution time: 0.0251
INFO - 2025-02-28 18:59:55 --> Config Class Initialized
INFO - 2025-02-28 18:59:55 --> Hooks Class Initialized
DEBUG - 2025-02-28 18:59:55 --> UTF-8 Support Enabled
INFO - 2025-02-28 18:59:55 --> Utf8 Class Initialized
INFO - 2025-02-28 18:59:55 --> URI Class Initialized
INFO - 2025-02-28 18:59:55 --> Router Class Initialized
INFO - 2025-02-28 18:59:55 --> Output Class Initialized
INFO - 2025-02-28 18:59:55 --> Security Class Initialized
DEBUG - 2025-02-28 18:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 18:59:55 --> Input Class Initialized
INFO - 2025-02-28 18:59:55 --> Language Class Initialized
ERROR - 2025-02-28 18:59:55 --> 404 Page Not Found: Passport/17b115107aaa1714fb2f01da83b832ab.jpg
INFO - 2025-02-28 19:00:06 --> Config Class Initialized
INFO - 2025-02-28 19:00:06 --> Hooks Class Initialized
DEBUG - 2025-02-28 19:00:06 --> UTF-8 Support Enabled
INFO - 2025-02-28 19:00:06 --> Utf8 Class Initialized
INFO - 2025-02-28 19:00:06 --> URI Class Initialized
INFO - 2025-02-28 19:00:06 --> Router Class Initialized
INFO - 2025-02-28 19:00:06 --> Output Class Initialized
INFO - 2025-02-28 19:00:06 --> Security Class Initialized
DEBUG - 2025-02-28 19:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 19:00:06 --> Input Class Initialized
INFO - 2025-02-28 19:00:06 --> Language Class Initialized
INFO - 2025-02-28 19:00:06 --> Loader Class Initialized
INFO - 2025-02-28 19:00:06 --> Helper loaded: url_helper
INFO - 2025-02-28 19:00:06 --> Helper loaded: file_helper
INFO - 2025-02-28 19:00:06 --> Helper loaded: jwt_helper
INFO - 2025-02-28 19:00:06 --> Database Driver Class Initialized
INFO - 2025-02-28 19:00:06 --> Email Class Initialized
INFO - 2025-02-28 19:00:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 19:00:06 --> PHPMailer loaded successfully
INFO - 2025-02-28 19:00:06 --> Upload Class Initialized
INFO - 2025-02-28 19:00:06 --> Model "Auth_model" initialized
INFO - 2025-02-28 19:00:06 --> Controller Class Initialized
INFO - 2025-02-28 19:00:06 --> Model "Payslips_model" initialized
DEBUG - 2025-02-28 19:00:06 --> PDFParser loaded successfully
INFO - 2025-02-28 19:00:06 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/header.php
INFO - 2025-02-28 19:00:06 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/lside.php
INFO - 2025-02-28 19:00:06 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/pageheader.php
INFO - 2025-02-28 19:00:06 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/footer.php
INFO - 2025-02-28 19:00:06 --> File loaded: C:\wamp64\www\fubkportal\application\views\payslips/slips.php
INFO - 2025-02-28 19:00:06 --> Final output sent to browser
DEBUG - 2025-02-28 19:00:06 --> Total execution time: 0.0999
INFO - 2025-02-28 19:00:10 --> Config Class Initialized
INFO - 2025-02-28 19:00:10 --> Hooks Class Initialized
DEBUG - 2025-02-28 19:00:10 --> UTF-8 Support Enabled
INFO - 2025-02-28 19:00:10 --> Utf8 Class Initialized
INFO - 2025-02-28 19:00:10 --> URI Class Initialized
INFO - 2025-02-28 19:00:10 --> Router Class Initialized
INFO - 2025-02-28 19:00:10 --> Output Class Initialized
INFO - 2025-02-28 19:00:10 --> Security Class Initialized
DEBUG - 2025-02-28 19:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 19:00:10 --> Input Class Initialized
INFO - 2025-02-28 19:00:10 --> Language Class Initialized
ERROR - 2025-02-28 19:00:10 --> 404 Page Not Found: Payslips/OCTOBER2023
INFO - 2025-02-28 19:00:10 --> Config Class Initialized
INFO - 2025-02-28 19:00:10 --> Hooks Class Initialized
DEBUG - 2025-02-28 19:00:10 --> UTF-8 Support Enabled
INFO - 2025-02-28 19:00:10 --> Utf8 Class Initialized
INFO - 2025-02-28 19:00:10 --> URI Class Initialized
INFO - 2025-02-28 19:00:10 --> Router Class Initialized
INFO - 2025-02-28 19:00:10 --> Output Class Initialized
INFO - 2025-02-28 19:00:10 --> Security Class Initialized
DEBUG - 2025-02-28 19:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 19:00:10 --> Input Class Initialized
INFO - 2025-02-28 19:00:10 --> Language Class Initialized
ERROR - 2025-02-28 19:00:10 --> 404 Page Not Found: Payslips/OCTOBER2023
INFO - 2025-02-28 19:00:10 --> Config Class Initialized
INFO - 2025-02-28 19:00:10 --> Hooks Class Initialized
DEBUG - 2025-02-28 19:00:10 --> UTF-8 Support Enabled
INFO - 2025-02-28 19:00:10 --> Utf8 Class Initialized
INFO - 2025-02-28 19:00:10 --> URI Class Initialized
INFO - 2025-02-28 19:00:10 --> Router Class Initialized
INFO - 2025-02-28 19:00:10 --> Output Class Initialized
INFO - 2025-02-28 19:00:10 --> Security Class Initialized
DEBUG - 2025-02-28 19:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 19:00:10 --> Input Class Initialized
INFO - 2025-02-28 19:00:10 --> Language Class Initialized
ERROR - 2025-02-28 19:00:10 --> 404 Page Not Found: Payslips/OCTOBER2023
INFO - 2025-02-28 19:00:10 --> Config Class Initialized
INFO - 2025-02-28 19:00:10 --> Hooks Class Initialized
DEBUG - 2025-02-28 19:00:10 --> UTF-8 Support Enabled
INFO - 2025-02-28 19:00:10 --> Utf8 Class Initialized
INFO - 2025-02-28 19:00:10 --> URI Class Initialized
INFO - 2025-02-28 19:00:10 --> Router Class Initialized
INFO - 2025-02-28 19:00:10 --> Output Class Initialized
INFO - 2025-02-28 19:00:10 --> Security Class Initialized
DEBUG - 2025-02-28 19:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 19:00:10 --> Input Class Initialized
INFO - 2025-02-28 19:00:10 --> Language Class Initialized
ERROR - 2025-02-28 19:00:10 --> 404 Page Not Found: Payslips/OCTOBER2023
INFO - 2025-02-28 19:00:12 --> Config Class Initialized
INFO - 2025-02-28 19:00:12 --> Hooks Class Initialized
DEBUG - 2025-02-28 19:00:12 --> UTF-8 Support Enabled
INFO - 2025-02-28 19:00:12 --> Utf8 Class Initialized
INFO - 2025-02-28 19:00:12 --> URI Class Initialized
INFO - 2025-02-28 19:00:12 --> Router Class Initialized
INFO - 2025-02-28 19:00:12 --> Output Class Initialized
INFO - 2025-02-28 19:00:12 --> Security Class Initialized
DEBUG - 2025-02-28 19:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 19:00:12 --> Input Class Initialized
INFO - 2025-02-28 19:00:12 --> Language Class Initialized
ERROR - 2025-02-28 19:00:12 --> 404 Page Not Found: Payslips/OCTOBER2023
INFO - 2025-02-28 19:19:56 --> Config Class Initialized
INFO - 2025-02-28 19:19:56 --> Hooks Class Initialized
DEBUG - 2025-02-28 19:19:56 --> UTF-8 Support Enabled
INFO - 2025-02-28 19:19:56 --> Utf8 Class Initialized
INFO - 2025-02-28 19:19:56 --> URI Class Initialized
INFO - 2025-02-28 19:19:56 --> Router Class Initialized
INFO - 2025-02-28 19:19:56 --> Output Class Initialized
INFO - 2025-02-28 19:19:56 --> Security Class Initialized
DEBUG - 2025-02-28 19:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 19:19:56 --> Input Class Initialized
INFO - 2025-02-28 19:19:56 --> Language Class Initialized
ERROR - 2025-02-28 19:19:56 --> 404 Page Not Found: Localhost/fubkportal
INFO - 2025-02-28 19:20:07 --> Config Class Initialized
INFO - 2025-02-28 19:20:07 --> Hooks Class Initialized
DEBUG - 2025-02-28 19:20:07 --> UTF-8 Support Enabled
INFO - 2025-02-28 19:20:07 --> Utf8 Class Initialized
INFO - 2025-02-28 19:20:07 --> URI Class Initialized
INFO - 2025-02-28 19:20:07 --> Router Class Initialized
INFO - 2025-02-28 19:20:07 --> Output Class Initialized
INFO - 2025-02-28 19:20:07 --> Security Class Initialized
DEBUG - 2025-02-28 19:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 19:20:07 --> Input Class Initialized
INFO - 2025-02-28 19:20:07 --> Language Class Initialized
INFO - 2025-02-28 19:20:07 --> Loader Class Initialized
INFO - 2025-02-28 19:20:07 --> Helper loaded: url_helper
INFO - 2025-02-28 19:20:07 --> Helper loaded: file_helper
INFO - 2025-02-28 19:20:07 --> Helper loaded: jwt_helper
INFO - 2025-02-28 19:20:07 --> Database Driver Class Initialized
INFO - 2025-02-28 19:20:07 --> Email Class Initialized
INFO - 2025-02-28 19:20:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 19:20:07 --> PHPMailer loaded successfully
INFO - 2025-02-28 19:20:07 --> Upload Class Initialized
INFO - 2025-02-28 19:20:07 --> Model "Auth_model" initialized
INFO - 2025-02-28 19:20:07 --> Controller Class Initialized
INFO - 2025-02-28 19:20:07 --> Model "Payslips_model" initialized
DEBUG - 2025-02-28 19:20:07 --> PDFParser loaded successfully
INFO - 2025-02-28 19:20:07 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/header.php
INFO - 2025-02-28 19:20:07 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/lside.php
INFO - 2025-02-28 19:23:49 --> Config Class Initialized
INFO - 2025-02-28 19:23:49 --> Hooks Class Initialized
DEBUG - 2025-02-28 19:23:49 --> UTF-8 Support Enabled
INFO - 2025-02-28 19:23:49 --> Utf8 Class Initialized
INFO - 2025-02-28 19:23:49 --> URI Class Initialized
INFO - 2025-02-28 19:23:49 --> Router Class Initialized
INFO - 2025-02-28 19:23:49 --> Output Class Initialized
INFO - 2025-02-28 19:23:49 --> Security Class Initialized
DEBUG - 2025-02-28 19:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 19:23:49 --> Input Class Initialized
INFO - 2025-02-28 19:23:49 --> Language Class Initialized
INFO - 2025-02-28 19:23:49 --> Loader Class Initialized
INFO - 2025-02-28 19:23:49 --> Helper loaded: url_helper
INFO - 2025-02-28 19:23:49 --> Helper loaded: file_helper
INFO - 2025-02-28 19:23:49 --> Helper loaded: jwt_helper
INFO - 2025-02-28 19:23:49 --> Database Driver Class Initialized
INFO - 2025-02-28 19:23:49 --> Email Class Initialized
INFO - 2025-02-28 19:23:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 19:23:49 --> PHPMailer loaded successfully
INFO - 2025-02-28 19:23:49 --> Upload Class Initialized
INFO - 2025-02-28 19:23:49 --> Model "Auth_model" initialized
INFO - 2025-02-28 19:23:49 --> Controller Class Initialized
INFO - 2025-02-28 19:23:49 --> Model "Payslips_model" initialized
DEBUG - 2025-02-28 19:23:49 --> PDFParser loaded successfully
INFO - 2025-02-28 19:23:49 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/header.php
INFO - 2025-02-28 19:23:49 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/lside.php
INFO - 2025-02-28 19:23:49 --> Config Class Initialized
INFO - 2025-02-28 19:23:49 --> Hooks Class Initialized
DEBUG - 2025-02-28 19:23:49 --> UTF-8 Support Enabled
INFO - 2025-02-28 19:23:49 --> Utf8 Class Initialized
INFO - 2025-02-28 19:23:49 --> URI Class Initialized
INFO - 2025-02-28 19:23:49 --> Router Class Initialized
INFO - 2025-02-28 19:23:49 --> Output Class Initialized
INFO - 2025-02-28 19:23:49 --> Security Class Initialized
DEBUG - 2025-02-28 19:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 19:23:49 --> Input Class Initialized
INFO - 2025-02-28 19:23:49 --> Language Class Initialized
INFO - 2025-02-28 19:23:49 --> Loader Class Initialized
INFO - 2025-02-28 19:23:49 --> Helper loaded: url_helper
INFO - 2025-02-28 19:23:49 --> Helper loaded: file_helper
INFO - 2025-02-28 19:23:49 --> Helper loaded: jwt_helper
INFO - 2025-02-28 19:23:49 --> Database Driver Class Initialized
INFO - 2025-02-28 19:23:49 --> Email Class Initialized
INFO - 2025-02-28 19:23:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 19:23:49 --> PHPMailer loaded successfully
INFO - 2025-02-28 19:23:49 --> Upload Class Initialized
INFO - 2025-02-28 19:23:49 --> Model "Auth_model" initialized
INFO - 2025-02-28 19:23:49 --> Controller Class Initialized
INFO - 2025-02-28 19:23:49 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 19:23:49 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 19:23:49 --> Config Class Initialized
INFO - 2025-02-28 19:23:49 --> Hooks Class Initialized
DEBUG - 2025-02-28 19:23:49 --> UTF-8 Support Enabled
INFO - 2025-02-28 19:23:49 --> Utf8 Class Initialized
INFO - 2025-02-28 19:23:49 --> URI Class Initialized
INFO - 2025-02-28 19:23:49 --> Router Class Initialized
INFO - 2025-02-28 19:23:49 --> Output Class Initialized
INFO - 2025-02-28 19:23:49 --> Security Class Initialized
DEBUG - 2025-02-28 19:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 19:23:49 --> Input Class Initialized
INFO - 2025-02-28 19:23:49 --> Language Class Initialized
INFO - 2025-02-28 19:23:49 --> Loader Class Initialized
INFO - 2025-02-28 19:23:49 --> Helper loaded: url_helper
INFO - 2025-02-28 19:23:49 --> Helper loaded: file_helper
INFO - 2025-02-28 19:23:49 --> Helper loaded: jwt_helper
INFO - 2025-02-28 19:23:49 --> Database Driver Class Initialized
INFO - 2025-02-28 19:23:49 --> Email Class Initialized
INFO - 2025-02-28 19:23:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 19:23:49 --> PHPMailer loaded successfully
INFO - 2025-02-28 19:23:49 --> Upload Class Initialized
INFO - 2025-02-28 19:23:49 --> Model "Auth_model" initialized
INFO - 2025-02-28 19:23:49 --> Controller Class Initialized
INFO - 2025-02-28 19:23:49 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 19:23:49 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 19:23:49 --> Config Class Initialized
INFO - 2025-02-28 19:23:49 --> Hooks Class Initialized
DEBUG - 2025-02-28 19:23:49 --> UTF-8 Support Enabled
INFO - 2025-02-28 19:23:49 --> Utf8 Class Initialized
INFO - 2025-02-28 19:23:49 --> URI Class Initialized
INFO - 2025-02-28 19:23:49 --> Router Class Initialized
INFO - 2025-02-28 19:23:49 --> Output Class Initialized
INFO - 2025-02-28 19:23:49 --> Security Class Initialized
DEBUG - 2025-02-28 19:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 19:23:49 --> Input Class Initialized
INFO - 2025-02-28 19:23:49 --> Language Class Initialized
INFO - 2025-02-28 19:23:49 --> Loader Class Initialized
INFO - 2025-02-28 19:23:49 --> Helper loaded: url_helper
INFO - 2025-02-28 19:23:49 --> Helper loaded: file_helper
INFO - 2025-02-28 19:23:49 --> Helper loaded: jwt_helper
INFO - 2025-02-28 19:23:49 --> Database Driver Class Initialized
INFO - 2025-02-28 19:23:49 --> Email Class Initialized
INFO - 2025-02-28 19:23:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 19:23:49 --> PHPMailer loaded successfully
INFO - 2025-02-28 19:23:49 --> Upload Class Initialized
INFO - 2025-02-28 19:23:49 --> Model "Auth_model" initialized
INFO - 2025-02-28 19:23:49 --> Controller Class Initialized
INFO - 2025-02-28 19:23:49 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 19:23:49 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 19:23:49 --> File loaded: C:\wamp64\www\fubkportal\application\views\login.php
INFO - 2025-02-28 19:23:49 --> Final output sent to browser
DEBUG - 2025-02-28 19:23:49 --> Total execution time: 0.0410
INFO - 2025-02-28 19:24:12 --> Config Class Initialized
INFO - 2025-02-28 19:24:12 --> Hooks Class Initialized
DEBUG - 2025-02-28 19:24:12 --> UTF-8 Support Enabled
INFO - 2025-02-28 19:24:12 --> Utf8 Class Initialized
INFO - 2025-02-28 19:24:12 --> URI Class Initialized
INFO - 2025-02-28 19:24:12 --> Router Class Initialized
INFO - 2025-02-28 19:24:12 --> Output Class Initialized
INFO - 2025-02-28 19:24:12 --> Security Class Initialized
DEBUG - 2025-02-28 19:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 19:24:12 --> Input Class Initialized
INFO - 2025-02-28 19:24:12 --> Language Class Initialized
INFO - 2025-02-28 19:24:12 --> Loader Class Initialized
INFO - 2025-02-28 19:24:12 --> Helper loaded: url_helper
INFO - 2025-02-28 19:24:12 --> Helper loaded: file_helper
INFO - 2025-02-28 19:24:12 --> Helper loaded: jwt_helper
INFO - 2025-02-28 19:24:12 --> Database Driver Class Initialized
INFO - 2025-02-28 19:24:12 --> Email Class Initialized
INFO - 2025-02-28 19:24:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 19:24:12 --> PHPMailer loaded successfully
INFO - 2025-02-28 19:24:12 --> Upload Class Initialized
INFO - 2025-02-28 19:24:12 --> Model "Auth_model" initialized
INFO - 2025-02-28 19:24:12 --> Controller Class Initialized
INFO - 2025-02-28 19:24:12 --> Model "Payment_model" initialized
DEBUG - 2025-02-28 19:24:12 --> Phpmailer_lib class already loaded. Second attempt ignored.
INFO - 2025-02-28 19:24:13 --> Config Class Initialized
INFO - 2025-02-28 19:24:13 --> Hooks Class Initialized
DEBUG - 2025-02-28 19:24:13 --> UTF-8 Support Enabled
INFO - 2025-02-28 19:24:13 --> Utf8 Class Initialized
INFO - 2025-02-28 19:24:13 --> URI Class Initialized
INFO - 2025-02-28 19:24:13 --> Router Class Initialized
INFO - 2025-02-28 19:24:13 --> Output Class Initialized
INFO - 2025-02-28 19:24:13 --> Security Class Initialized
DEBUG - 2025-02-28 19:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 19:24:13 --> Input Class Initialized
INFO - 2025-02-28 19:24:13 --> Language Class Initialized
INFO - 2025-02-28 19:24:13 --> Loader Class Initialized
INFO - 2025-02-28 19:24:13 --> Helper loaded: url_helper
INFO - 2025-02-28 19:24:13 --> Helper loaded: file_helper
INFO - 2025-02-28 19:24:13 --> Helper loaded: jwt_helper
INFO - 2025-02-28 19:24:13 --> Database Driver Class Initialized
INFO - 2025-02-28 19:24:13 --> Email Class Initialized
INFO - 2025-02-28 19:24:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 19:24:13 --> PHPMailer loaded successfully
INFO - 2025-02-28 19:24:13 --> Upload Class Initialized
INFO - 2025-02-28 19:24:13 --> Model "Auth_model" initialized
INFO - 2025-02-28 19:24:13 --> Controller Class Initialized
INFO - 2025-02-28 19:24:13 --> Model "Staff_model" initialized
INFO - 2025-02-28 19:24:13 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/header.php
INFO - 2025-02-28 19:24:13 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/lside.php
INFO - 2025-02-28 19:24:13 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/pageheader.php
INFO - 2025-02-28 19:24:13 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/footer.php
INFO - 2025-02-28 19:24:13 --> File loaded: C:\wamp64\www\fubkportal\application\views\staff/index.php
INFO - 2025-02-28 19:24:13 --> Final output sent to browser
DEBUG - 2025-02-28 19:24:13 --> Total execution time: 0.0209
INFO - 2025-02-28 19:24:13 --> Config Class Initialized
INFO - 2025-02-28 19:24:13 --> Hooks Class Initialized
DEBUG - 2025-02-28 19:24:13 --> UTF-8 Support Enabled
INFO - 2025-02-28 19:24:13 --> Utf8 Class Initialized
INFO - 2025-02-28 19:24:13 --> URI Class Initialized
INFO - 2025-02-28 19:24:13 --> Router Class Initialized
INFO - 2025-02-28 19:24:13 --> Output Class Initialized
INFO - 2025-02-28 19:24:13 --> Security Class Initialized
DEBUG - 2025-02-28 19:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 19:24:13 --> Input Class Initialized
INFO - 2025-02-28 19:24:13 --> Language Class Initialized
ERROR - 2025-02-28 19:24:13 --> 404 Page Not Found: Passport/17b115107aaa1714fb2f01da83b832ab.jpg
INFO - 2025-02-28 19:24:25 --> Config Class Initialized
INFO - 2025-02-28 19:24:25 --> Hooks Class Initialized
DEBUG - 2025-02-28 19:24:25 --> UTF-8 Support Enabled
INFO - 2025-02-28 19:24:25 --> Utf8 Class Initialized
INFO - 2025-02-28 19:24:25 --> URI Class Initialized
INFO - 2025-02-28 19:24:25 --> Router Class Initialized
INFO - 2025-02-28 19:24:25 --> Output Class Initialized
INFO - 2025-02-28 19:24:25 --> Security Class Initialized
DEBUG - 2025-02-28 19:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 19:24:25 --> Input Class Initialized
INFO - 2025-02-28 19:24:25 --> Language Class Initialized
INFO - 2025-02-28 19:24:25 --> Loader Class Initialized
INFO - 2025-02-28 19:24:25 --> Helper loaded: url_helper
INFO - 2025-02-28 19:24:25 --> Helper loaded: file_helper
INFO - 2025-02-28 19:24:25 --> Helper loaded: jwt_helper
INFO - 2025-02-28 19:24:25 --> Database Driver Class Initialized
INFO - 2025-02-28 19:24:25 --> Email Class Initialized
INFO - 2025-02-28 19:24:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 19:24:25 --> PHPMailer loaded successfully
INFO - 2025-02-28 19:24:25 --> Upload Class Initialized
INFO - 2025-02-28 19:24:25 --> Model "Auth_model" initialized
INFO - 2025-02-28 19:24:25 --> Controller Class Initialized
INFO - 2025-02-28 19:24:25 --> Model "Accomodation_model" initialized
INFO - 2025-02-28 19:24:25 --> Model "Course_model" initialized
INFO - 2025-02-28 19:24:25 --> Model "Student_model" initialized
INFO - 2025-02-28 19:24:25 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/header.php
INFO - 2025-02-28 19:24:25 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/lside.php
INFO - 2025-02-28 19:24:25 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/pageheader.php
INFO - 2025-02-28 19:24:25 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/footer.php
INFO - 2025-02-28 19:24:25 --> File loaded: C:\wamp64\www\fubkportal\application\views\accomodations/index.php
INFO - 2025-02-28 19:24:25 --> Final output sent to browser
DEBUG - 2025-02-28 19:24:25 --> Total execution time: 0.0452
INFO - 2025-02-28 19:24:30 --> Config Class Initialized
INFO - 2025-02-28 19:24:30 --> Hooks Class Initialized
DEBUG - 2025-02-28 19:24:30 --> UTF-8 Support Enabled
INFO - 2025-02-28 19:24:30 --> Utf8 Class Initialized
INFO - 2025-02-28 19:24:30 --> URI Class Initialized
INFO - 2025-02-28 19:24:30 --> Router Class Initialized
INFO - 2025-02-28 19:24:30 --> Output Class Initialized
INFO - 2025-02-28 19:24:30 --> Security Class Initialized
DEBUG - 2025-02-28 19:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 19:24:30 --> Input Class Initialized
INFO - 2025-02-28 19:24:30 --> Language Class Initialized
INFO - 2025-02-28 19:24:30 --> Loader Class Initialized
INFO - 2025-02-28 19:24:30 --> Helper loaded: url_helper
INFO - 2025-02-28 19:24:30 --> Helper loaded: file_helper
INFO - 2025-02-28 19:24:30 --> Helper loaded: jwt_helper
INFO - 2025-02-28 19:24:30 --> Database Driver Class Initialized
INFO - 2025-02-28 19:24:30 --> Email Class Initialized
INFO - 2025-02-28 19:24:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 19:24:30 --> PHPMailer loaded successfully
INFO - 2025-02-28 19:24:30 --> Upload Class Initialized
INFO - 2025-02-28 19:24:30 --> Model "Auth_model" initialized
INFO - 2025-02-28 19:24:30 --> Controller Class Initialized
INFO - 2025-02-28 19:24:30 --> Model "Accomodation_model" initialized
INFO - 2025-02-28 19:24:30 --> Model "Course_model" initialized
INFO - 2025-02-28 19:24:30 --> Model "Student_model" initialized
ERROR - 2025-02-28 19:24:30 --> Query error: Unknown column 'ug_reservations.hostelid' in 'on clause' - Invalid query: SELECT *
FROM `ug_hostels`
JOIN `ug_reservations` ON `ug_hostels`.`id` = `ug_reservations`.`hostelid`
JOIN `ug_profiles` ON `ug_profiles`.`user_id` = `ug_reservations`.`userid`
JOIN `gen_programme` ON `gen_programme`.`id` = `ug_profiles`.`programid`
WHERE `ug_reservations`.`session` = '2022/2023'
AND `ug_reservations`.`reservation_status` = 'Pending'
AND `ug_hostels`.`id` = '6'
ORDER BY `datereserved` ASC
INFO - 2025-02-28 19:24:30 --> Language file loaded: language/english/db_lang.php
INFO - 2025-02-28 19:24:36 --> Config Class Initialized
INFO - 2025-02-28 19:24:36 --> Hooks Class Initialized
DEBUG - 2025-02-28 19:24:36 --> UTF-8 Support Enabled
INFO - 2025-02-28 19:24:36 --> Utf8 Class Initialized
INFO - 2025-02-28 19:24:36 --> URI Class Initialized
INFO - 2025-02-28 19:24:36 --> Router Class Initialized
INFO - 2025-02-28 19:24:36 --> Output Class Initialized
INFO - 2025-02-28 19:24:36 --> Security Class Initialized
DEBUG - 2025-02-28 19:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 19:24:36 --> Input Class Initialized
INFO - 2025-02-28 19:24:36 --> Language Class Initialized
INFO - 2025-02-28 19:24:36 --> Loader Class Initialized
INFO - 2025-02-28 19:24:36 --> Helper loaded: url_helper
INFO - 2025-02-28 19:24:36 --> Helper loaded: file_helper
INFO - 2025-02-28 19:24:36 --> Helper loaded: jwt_helper
INFO - 2025-02-28 19:24:36 --> Database Driver Class Initialized
INFO - 2025-02-28 19:24:36 --> Email Class Initialized
INFO - 2025-02-28 19:24:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 19:24:36 --> PHPMailer loaded successfully
INFO - 2025-02-28 19:24:36 --> Upload Class Initialized
INFO - 2025-02-28 19:24:36 --> Model "Auth_model" initialized
INFO - 2025-02-28 19:24:36 --> Controller Class Initialized
INFO - 2025-02-28 19:24:36 --> Model "Accomodation_model" initialized
INFO - 2025-02-28 19:24:36 --> Model "Course_model" initialized
INFO - 2025-02-28 19:24:36 --> Model "Student_model" initialized
INFO - 2025-02-28 19:24:36 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/header.php
INFO - 2025-02-28 19:24:36 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/lside.php
INFO - 2025-02-28 19:24:36 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/pageheader.php
INFO - 2025-02-28 19:24:36 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/footer.php
INFO - 2025-02-28 19:24:36 --> File loaded: C:\wamp64\www\fubkportal\application\views\accomodations/index.php
INFO - 2025-02-28 19:24:36 --> Final output sent to browser
DEBUG - 2025-02-28 19:24:36 --> Total execution time: 0.0299
INFO - 2025-02-28 19:24:41 --> Config Class Initialized
INFO - 2025-02-28 19:24:41 --> Hooks Class Initialized
DEBUG - 2025-02-28 19:24:41 --> UTF-8 Support Enabled
INFO - 2025-02-28 19:24:41 --> Utf8 Class Initialized
INFO - 2025-02-28 19:24:41 --> URI Class Initialized
INFO - 2025-02-28 19:24:41 --> Router Class Initialized
INFO - 2025-02-28 19:24:41 --> Output Class Initialized
INFO - 2025-02-28 19:24:41 --> Security Class Initialized
DEBUG - 2025-02-28 19:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-02-28 19:24:41 --> Input Class Initialized
INFO - 2025-02-28 19:24:41 --> Language Class Initialized
INFO - 2025-02-28 19:24:41 --> Loader Class Initialized
INFO - 2025-02-28 19:24:41 --> Helper loaded: url_helper
INFO - 2025-02-28 19:24:41 --> Helper loaded: file_helper
INFO - 2025-02-28 19:24:41 --> Helper loaded: jwt_helper
INFO - 2025-02-28 19:24:41 --> Database Driver Class Initialized
INFO - 2025-02-28 19:24:41 --> Email Class Initialized
INFO - 2025-02-28 19:24:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-02-28 19:24:41 --> PHPMailer loaded successfully
INFO - 2025-02-28 19:24:41 --> Upload Class Initialized
INFO - 2025-02-28 19:24:41 --> Model "Auth_model" initialized
INFO - 2025-02-28 19:24:41 --> Controller Class Initialized
INFO - 2025-02-28 19:24:41 --> Model "Accomodation_model" initialized
INFO - 2025-02-28 19:24:41 --> Model "Course_model" initialized
INFO - 2025-02-28 19:24:41 --> Model "Student_model" initialized
INFO - 2025-02-28 19:24:41 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/header.php
INFO - 2025-02-28 19:24:41 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/lside.php
INFO - 2025-02-28 19:24:41 --> File loaded: C:\wamp64\www\fubkportal\application\views\incs/footer.php
INFO - 2025-02-28 19:24:41 --> File loaded: C:\wamp64\www\fubkportal\application\views\accomodations/hostel.php
INFO - 2025-02-28 19:24:41 --> Final output sent to browser
DEBUG - 2025-02-28 19:24:41 --> Total execution time: 0.0378
